# IPTrip - PRD

## Problem statement
Adicionar ao site IPTrip: (1) dropdown de mudança de idioma (PT-PT, EN, ES, FR);
(2) dropdown de moeda (EUR, USD, GBP, ARS) com conversão real dos preços e símbolo
nos cards; (3) botão "Comprar Agora" nos cards que leva a uma página de checkout/pagamento;
(4) barra de pesquisa inteligente com IA para escolher a melhor viagem dentro dos parâmetros.

## Stack
- Backend: Flask (uvicorn ASGI via server.py) + **MariaDB 10.11** (MySQL-compatible), port 8001
- Frontend: HTML/CSS/JS estático (npx serve), port 3000
- IA: heurística local (sem LLM)
- Moedas: open.er-api.com (gratuito, sem chave)
- BD: MariaDB gerida por supervisor (`/etc/supervisor/conf.d/supervisord_mariadb.conf`)

## Implementado (Jun/2026)
- `/api/exchange-rates` – taxas EUR-base com cache 1h e fallback
- `/api/ai-search` – **pesquisa heurística local** (sem LLM, sem chave externa). Extrai orçamento,
  duração, estilo (praia/cultural/romântico/aventura/luxo/urbano/gastronomia) e continente
  da query em PT/EN/ES/FR, e ordena os destinos/pacotes por relevância.
- `/api/checkout` – mock de pagamento com validação cartão + criação de booking (guest)
- `/api/login` devolve `role` e `is_admin` para permitir UI diferenciada por papel
- `/api/admin/*` – endpoints protegidos por `X-User-Id` + verificação de role em DB:
  - `GET /stats`, `GET/PATCH/DELETE /bookings`, `GET /users`
  - `POST/PUT/DELETE /destinations`, `POST/PUT/DELETE /packages`
- `frontend/js/i18n.js` – injecta dropdowns na navbar, converte preços e re-renderiza eventos
- `frontend/js/translations.js` – dicionário completo PT/EN/ES/FR
- Botão "Comprar Agora" em cards de destinos e pacotes (home, /destinos, /pacotes)
- `checkout.html` + `checkout.js` – formulário viajante + cartão + resumo dinâmico
- Página de sucesso com código de confirmação e card last4
- **`/admin.html` + `admin.js` + `admin.css`** – consola completa com 5 secções
  (Visão Geral · Reservas · Destinos · Pacotes · Utilizadores), incluindo CRUD modais.

## Backlog
- Substituir mock de pagamento por Stripe real
- Tradução do conteúdo dinâmico vindo da BD (descrições de pacotes/destinos)
- Aumentar budget da EMERGENT_LLM_KEY (intermitências a $0.001 cap)
