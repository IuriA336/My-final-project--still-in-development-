# IPTrip - Test Credentials

## Admin Account
- **Email:** `admin@iptrip.com`
- **Password:** `Admin@IPTrip2026`
- **Role:** `admin`
- **Tipo de conta:** `admin`

## Database (MariaDB / MySQL-compatible)
- Host: `127.0.0.1`
- Port: `3306`
- User: `iptrip`
- Password: `iptrip_secret_2026`
- Database: `iptrip`

CLI access:
```
mariadb -u iptrip -piptrip_secret_2026 -D iptrip
```

## Auth Endpoints (Flask backend, port 8001)
- `POST /api/login`  → body `{email, password}`  → returns `{status, user_id, nome}`
- `POST /api/register` → body `{nome, email, telefone, password}` → returns `{status, user_id}`

## Notes
- The admin row is seeded **idempotently** on backend startup from the
  `ADMIN_EMAIL` / `ADMIN_PASSWORD` env vars in `/app/backend/.env`.
- Changing those env vars and restarting the backend updates the password hash
  in place — no manual migration required.
- All previous test data (3 guest users + 3 bookings) was dropped during the
  SQLite → MariaDB migration.
