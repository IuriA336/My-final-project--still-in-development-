"""Static translations of the catalogue.

The catalogue is small (12 destinations + 8 packages), so we keep a hand-curated
dictionary instead of calling an external translation API. Keys are the
Portuguese source strings, values are dicts keyed by locale.
"""

DESTINATIONS = {
    # Paris
    1: {
        "en": {"nome": "Paris", "pais": "France",
               "descricao": "The City of Light offers romance, art and incomparable gastronomy. Stroll the Champs-Élysées, visit the Louvre and enjoy fresh croissants in charming cafés.",
               "destaques": ["Eiffel Tower", "Louvre Museum", "Arc de Triomphe", "Notre-Dame"]},
        "es": {"nome": "París", "pais": "Francia",
               "descricao": "La Ciudad de la Luz ofrece romance, arte y una gastronomía incomparable. Pasea por los Campos Elíseos, visita el Louvre y disfruta de croissants frescos en cafés con encanto.",
               "destaques": ["Torre Eiffel", "Museo del Louvre", "Arco de Triunfo", "Notre-Dame"]},
        "fr": {"nome": "Paris", "pais": "France",
               "descricao": "La Ville Lumière offre romance, art et une gastronomie incomparable. Promenez-vous sur les Champs-Élysées, visitez le Louvre et savourez de croissants frais dans des cafés de charme.",
               "destaques": ["Tour Eiffel", "Musée du Louvre", "Arc de Triomphe", "Notre-Dame"]},
    },
    # Maldivas
    2: {
        "en": {"nome": "Maldives", "pais": "Maldives",
               "descricao": "Tropical paradise with crystal-clear waters and exclusive resorts. Overwater bungalows, diving with exotic marine life and unforgettable sunsets.",
               "destaques": ["Overwater resorts", "Diving", "Paradise beaches", "Luxury spa"]},
        "es": {"nome": "Maldivas", "pais": "Maldivas",
               "descricao": "Paraíso tropical con aguas cristalinas y resorts exclusivos. Bungalós sobre el agua, buceo con vida marina exótica y atardeceres inolvidables.",
               "destaques": ["Resorts sobre el agua", "Buceo", "Playas paradisíacas", "Spa de lujo"]},
        "fr": {"nome": "Maldives", "pais": "Maldives",
               "descricao": "Paradis tropical aux eaux cristallines et resorts exclusifs. Bungalows sur l'eau, plongée avec vie marine exotique et couchers de soleil inoubliables.",
               "destaques": ["Resorts sur pilotis", "Plongée", "Plages paradisiaques", "Spa de luxe"]},
    },
    # Nova York
    3: {
        "en": {"nome": "New York", "pais": "United States",
               "descricao": "The city that never sleeps, full of culture, art and entertainment. From Broadway to Central Park, every corner tells a story.",
               "destaques": ["Statue of Liberty", "Central Park", "Times Square", "Broadway"]},
        "es": {"nome": "Nueva York", "pais": "Estados Unidos",
               "descricao": "La ciudad que nunca duerme, repleta de cultura, arte y entretenimiento. De Broadway a Central Park, cada esquina cuenta una historia.",
               "destaques": ["Estatua de la Libertad", "Central Park", "Times Square", "Broadway"]},
        "fr": {"nome": "New York", "pais": "États-Unis",
               "descricao": "La ville qui ne dort jamais, remplie de culture, d'art et de divertissement. De Broadway à Central Park, chaque coin raconte une histoire.",
               "destaques": ["Statue de la Liberté", "Central Park", "Times Square", "Broadway"]},
    },
    # Tóquio
    4: {
        "en": {"nome": "Tokyo", "pais": "Japan",
               "descricao": "A perfect blend of ancient tradition and futuristic technology. Ancient temples next to neon skyscrapers, and unique cuisine.",
               "destaques": ["Senso-ji Temple", "Shibuya Crossing", "Mount Fuji", "Akihabara"]},
        "es": {"nome": "Tokio", "pais": "Japón",
               "descricao": "Fusión perfecta entre tradición milenaria y tecnología futurista. Templos antiguos junto a rascacielos de neón, gastronomía única.",
               "destaques": ["Templo Senso-ji", "Cruce de Shibuya", "Monte Fuji", "Akihabara"]},
        "fr": {"nome": "Tokyo", "pais": "Japon",
               "descricao": "Fusion parfaite entre tradition millénaire et technologie futuriste. Temples anciens à côté de gratte-ciel néon, gastronomie unique.",
               "destaques": ["Temple Senso-ji", "Carrefour de Shibuya", "Mont Fuji", "Akihabara"]},
    },
    # Cancún
    5: {
        "en": {"nome": "Cancun", "pais": "Mexico",
               "descricao": "Paradise beaches and Mayan ruins in one place. Turquoise waters, mysterious cenotes and vibrant nightlife.",
               "destaques": ["White-sand beaches", "Mayan ruins", "Cenotes", "Nightlife"]},
        "es": {"nome": "Cancún", "pais": "México",
               "descricao": "Playas paradisíacas y ruinas mayas en un solo lugar. Aguas turquesa, cenotes misteriosos y vibrante vida nocturna.",
               "destaques": ["Playas de arena blanca", "Ruinas mayas", "Cenotes", "Vida nocturna"]},
        "fr": {"nome": "Cancún", "pais": "Mexique",
               "descricao": "Plages paradisiaques et ruines mayas en un seul endroit. Eaux turquoise, cénotes mystérieux et vie nocturne vibrante.",
               "destaques": ["Plages de sable blanc", "Ruines mayas", "Cénotes", "Vie nocturne"]},
    },
    # Dubai
    6: {
        "en": {"nome": "Dubai", "pais": "United Arab Emirates",
               "descricao": "Luxury and modernity in the heart of the Arabian desert. Record-breaking skyscrapers, gigantic shopping malls and unique experiences.",
               "destaques": ["Burj Khalifa", "Dubai Mall", "Desert safari", "Palm Jumeirah"]},
        "es": {"nome": "Dubái", "pais": "Emiratos Árabes Unidos",
               "descricao": "Lujo y modernidad en el corazón del desierto árabe. Rascacielos récord, centros comerciales gigantescos y experiencias únicas.",
               "destaques": ["Burj Khalifa", "Dubai Mall", "Safari en el desierto", "Palm Jumeirah"]},
        "fr": {"nome": "Dubaï", "pais": "Émirats arabes unis",
               "descricao": "Luxe et modernité au cœur du désert arabe. Gratte-ciel records, centres commerciaux gigantesques et expériences uniques.",
               "destaques": ["Burj Khalifa", "Dubai Mall", "Safari dans le désert", "Palm Jumeirah"]},
    },
    # Roma
    7: {
        "en": {"nome": "Rome", "pais": "Italy",
               "descricao": "The eternal city where history lives on every street. Colosseum, Vatican, artisanal gelato and the Italian dolce vita.",
               "destaques": ["Colosseum", "Vatican", "Trevi Fountain", "Pantheon"]},
        "es": {"nome": "Roma", "pais": "Italia",
               "descricao": "La ciudad eterna donde la historia vive en cada calle. Coliseo, Vaticano, helado artesanal y la dolce vita italiana.",
               "destaques": ["Coliseo", "Vaticano", "Fontana de Trevi", "Panteón"]},
        "fr": {"nome": "Rome", "pais": "Italie",
               "descricao": "La ville éternelle où l'histoire vit dans chaque rue. Colisée, Vatican, gelato artisanal et la dolce vita italienne.",
               "destaques": ["Colisée", "Vatican", "Fontaine de Trevi", "Panthéon"]},
    },
    # Santorini
    8: {
        "en": {"nome": "Santorini", "pais": "Greece",
               "descricao": "Greek islands with spectacular sunsets and iconic architecture. White houses with blue domes, local wines and volcanic beaches.",
               "destaques": ["Sunset in Oia", "Volcanic beaches", "Local wines", "Fira"]},
        "es": {"nome": "Santorini", "pais": "Grecia",
               "descricao": "Islas griegas con atardeceres espectaculares y arquitectura icónica. Casas blancas con cúpulas azules, vinos locales y playas volcánicas.",
               "destaques": ["Atardecer en Oia", "Playas volcánicas", "Vinos locales", "Fira"]},
        "fr": {"nome": "Santorin", "pais": "Grèce",
               "descricao": "Îles grecques avec des couchers de soleil spectaculaires et une architecture emblématique. Maisons blanches aux dômes bleus, vins locaux et plages volcaniques.",
               "destaques": ["Coucher de soleil à Oia", "Plages volcaniques", "Vins locaux", "Fira"]},
    },
    # Bali
    9: {
        "en": {"nome": "Bali", "pais": "Indonesia",
               "descricao": "Island of the gods with mystical temples, terraced rice fields and world-class surfing. Spirituality and nature in harmony.",
               "destaques": ["Uluwatu Temple", "Tegallalang rice fields", "Ubud", "Surf beaches"]},
        "es": {"nome": "Bali", "pais": "Indonesia",
               "descricao": "Isla de los dioses con templos místicos, arrozales en terrazas y surf de clase mundial. Espiritualidad y naturaleza en armonía.",
               "destaques": ["Templo Uluwatu", "Arrozales de Tegallalang", "Ubud", "Playas de surf"]},
        "fr": {"nome": "Bali", "pais": "Indonésie",
               "descricao": "Île des dieux aux temples mystiques, rizières en terrasses et surf de classe mondiale. Spiritualité et nature en harmonie.",
               "destaques": ["Temple Uluwatu", "Rizières de Tegallalang", "Ubud", "Spots de surf"]},
    },
    # Barcelona
    10: {
        "en": {"nome": "Barcelona", "pais": "Spain",
               "descricao": "Gaudí architecture, Mediterranean beaches and amazing tapas. A vibrant city where art, culture and celebration come together.",
               "destaques": ["Sagrada Família", "Park Güell", "Las Ramblas", "Barceloneta beach"]},
        "es": {"nome": "Barcelona", "pais": "España",
               "descricao": "Arquitectura de Gaudí, playas mediterráneas y tapas increíbles. Una ciudad vibrante donde el arte, la cultura y la fiesta se encuentran.",
               "destaques": ["Sagrada Familia", "Park Güell", "Las Ramblas", "Playa de la Barceloneta"]},
        "fr": {"nome": "Barcelone", "pais": "Espagne",
               "descricao": "Architecture de Gaudí, plages méditerranéennes et tapas incroyables. Une ville vibrante où l'art, la culture et la fête se rencontrent.",
               "destaques": ["Sagrada Família", "Parc Güell", "Las Ramblas", "Plage de la Barceloneta"]},
    },
    # Machu Picchu
    11: {
        "en": {"nome": "Machu Picchu", "pais": "Peru",
               "descricao": "Lost city of the Incas high in the Andes. One of the wonders of the modern world, full of mystery and natural beauty.",
               "destaques": ["Inca citadel", "Inca Trail", "Sacred Valley", "Aguas Calientes"]},
        "es": {"nome": "Machu Picchu", "pais": "Perú",
               "descricao": "Ciudad perdida de los Incas en las alturas de los Andes. Una de las maravillas del mundo moderno, llena de misterio y belleza natural.",
               "destaques": ["Ciudadela inca", "Camino del Inca", "Valle Sagrado", "Aguas Calientes"]},
        "fr": {"nome": "Machu Picchu", "pais": "Pérou",
               "descricao": "Cité perdue des Incas dans les hauteurs des Andes. L'une des merveilles du monde moderne, pleine de mystère et de beauté naturelle.",
               "destaques": ["Citadelle inca", "Chemin de l'Inca", "Vallée sacrée", "Aguas Calientes"]},
    },
    # Londres
    12: {
        "en": {"nome": "London", "pais": "United Kingdom",
               "descricao": "British capital with millennial history, world-class museums and vibrant cultural life. From Big Ben to Camden Town.",
               "destaques": ["Big Ben", "British Museum", "Tower Bridge", "Buckingham Palace"]},
        "es": {"nome": "Londres", "pais": "Reino Unido",
               "descricao": "Capital británica con historia milenaria, museos de clase mundial y vida cultural vibrante. Del Big Ben a Camden Town.",
               "destaques": ["Big Ben", "Museo Británico", "Tower Bridge", "Palacio de Buckingham"]},
        "fr": {"nome": "Londres", "pais": "Royaume-Uni",
               "descricao": "Capitale britannique à l'histoire millénaire, musées de classe mondiale et vie culturelle vibrante. De Big Ben à Camden Town.",
               "destaques": ["Big Ben", "British Museum", "Tower Bridge", "Palais de Buckingham"]},
    },
}

PACKAGES = {
    # Romance em Paris
    1: {
        "en": {"nome": "Romance in Paris", "destino_principal": "Paris",
               "descricao": "7 nights in a 4-star hotel with Eiffel Tower view, dinner at a Michelin restaurant and a Seine river cruise.",
               "itens_incluidos": ["Return flight", "4-star hotel", "Romantic dinner", "Seine river cruise"]},
        "es": {"nome": "Romance en París", "destino_principal": "París",
               "descricao": "7 noches en hotel 4 estrellas con vista a la Torre Eiffel, cena en restaurante Michelin y crucero por el Sena.",
               "itens_incluidos": ["Vuelo ida y vuelta", "Hotel 4 estrellas", "Cena romántica", "Crucero por el Sena"]},
        "fr": {"nome": "Romance à Paris", "destino_principal": "Paris",
               "descricao": "7 nuits dans un hôtel 4 étoiles avec vue sur la Tour Eiffel, dîner dans un restaurant Michelin et croisière sur la Seine.",
               "itens_incluidos": ["Vol aller-retour", "Hôtel 4 étoiles", "Dîner romantique", "Croisière sur la Seine"]},
    },
    # Lua de Mel nas Maldivas
    2: {
        "en": {"nome": "Maldives Honeymoon", "destino_principal": "Maldives",
               "descricao": "10 nights at an all-inclusive overwater resort with spa, diving and a private dinner on the beach.",
               "itens_incluidos": ["Overwater resort", "All-inclusive", "Couples spa", "Beach dinner"]},
        "es": {"nome": "Luna de Miel en Maldivas", "destino_principal": "Maldivas",
               "descricao": "10 noches en resort sobre el agua all-inclusive con spa, buceo y cena privada en la playa.",
               "itens_incluidos": ["Resort sobre el agua", "Todo incluido", "Spa para parejas", "Cena en la playa"]},
        "fr": {"nome": "Lune de Miel aux Maldives", "destino_principal": "Maldives",
               "descricao": "10 nuits dans un resort sur pilotis tout inclus avec spa, plongée et dîner privé sur la plage.",
               "itens_incluidos": ["Resort sur pilotis", "Tout inclus", "Spa pour couples", "Dîner sur la plage"]},
    },
    # Aventura em Tóquio
    3: {
        "en": {"nome": "Tokyo Adventure", "destino_principal": "Tokyo",
               "descricao": "8 nights exploring temples, neon districts, gastronomy and Japanese pop culture.",
               "itens_incluidos": ["Hotel in Shinjuku", "Japan Rail Pass", "Food tour", "Day trip to Mount Fuji"]},
        "es": {"nome": "Aventura en Tokio", "destino_principal": "Tokio",
               "descricao": "8 noches explorando templos, barrios de neón, gastronomía y cultura pop japonesa.",
               "itens_incluidos": ["Hotel en Shinjuku", "Japan Rail Pass", "Tour gastronómico", "Día en el Monte Fuji"]},
        "fr": {"nome": "Aventure à Tokyo", "destino_principal": "Tokyo",
               "descricao": "8 nuits à explorer temples, quartiers néon, gastronomie et culture pop japonaise.",
               "itens_incluidos": ["Hôtel à Shinjuku", "Japan Rail Pass", "Tour gastronomique", "Journée au Mont Fuji"]},
    },
    # New York Explorer
    4: {
        "en": {"nome": "New York Explorer", "destino_principal": "New York",
               "descricao": "5 nights in Manhattan with Broadway tickets, museum visits and a helicopter tour.",
               "itens_incluidos": ["Manhattan hotel", "Broadway tickets", "Museum entries", "Helicopter tour"]},
        "es": {"nome": "Nueva York Explorer", "destino_principal": "Nueva York",
               "descricao": "5 noches en Manhattan con entradas a Broadway, visitas a museos y tour en helicóptero.",
               "itens_incluidos": ["Hotel en Manhattan", "Entradas a Broadway", "Museos incluidos", "Tour en helicóptero"]},
        "fr": {"nome": "New York Explorer", "destino_principal": "New York",
               "descricao": "5 nuits à Manhattan avec billets pour Broadway, visites de musées et tour en hélicoptère.",
               "itens_incluidos": ["Hôtel à Manhattan", "Billets Broadway", "Musées inclus", "Tour en hélicoptère"]},
    },
    # Praias de Cancún
    5: {
        "en": {"nome": "Cancun Beaches", "destino_principal": "Cancun",
               "descricao": "7 nights all-inclusive at a 5-star resort with excursions to Mayan ruins and cenotes.",
               "itens_incluidos": ["5-star resort", "All-inclusive", "Mayan ruins tour", "Cenotes"]},
        "es": {"nome": "Playas de Cancún", "destino_principal": "Cancún",
               "descricao": "7 noches todo incluido en resort 5 estrellas con excursiones a ruinas mayas y cenotes.",
               "itens_incluidos": ["Resort 5 estrellas", "Todo incluido", "Tour ruinas mayas", "Cenotes"]},
        "fr": {"nome": "Plages de Cancún", "destino_principal": "Cancún",
               "descricao": "7 nuits tout inclus dans un resort 5 étoiles avec excursions vers les ruines mayas et les cénotes.",
               "itens_incluidos": ["Resort 5 étoiles", "Tout inclus", "Tour ruines mayas", "Cénotes"]},
    },
    # Dubai Luxury
    6: {
        "en": {"nome": "Dubai Luxury", "destino_principal": "Dubai",
               "descricao": "6 nights of luxury with a desert safari, Burj Khalifa and exclusive experiences.",
               "itens_incluidos": ["5-star hotel", "Desert safari", "Burj Khalifa VIP", "Dinner at Atmosphere"]},
        "es": {"nome": "Dubái de Lujo", "destino_principal": "Dubái",
               "descricao": "6 noches de lujo con safari en el desierto, Burj Khalifa y experiencias exclusivas.",
               "itens_incluidos": ["Hotel 5 estrellas", "Safari en el desierto", "Burj Khalifa VIP", "Cena en Atmosphere"]},
        "fr": {"nome": "Dubaï de Luxe", "destino_principal": "Dubaï",
               "descricao": "6 nuits de luxe avec safari dans le désert, Burj Khalifa et expériences exclusives.",
               "itens_incluidos": ["Hôtel 5 étoiles", "Safari dans le désert", "Burj Khalifa VIP", "Dîner à Atmosphere"]},
    },
    # Roma Clássica
    7: {
        "en": {"nome": "Classic Rome", "destino_principal": "Rome",
               "descricao": "5 nights discovering the Colosseum, the Vatican and authentic Italian cuisine.",
               "itens_incluidos": ["Central hotel", "Guided tour", "Cooking class", "Vatican skip-the-line"]},
        "es": {"nome": "Roma Clásica", "destino_principal": "Roma",
               "descricao": "5 noches descubriendo el Coliseo, el Vaticano y la auténtica gastronomía italiana.",
               "itens_incluidos": ["Hotel céntrico", "Tour guiado", "Clase de cocina", "Vaticano sin colas"]},
        "fr": {"nome": "Rome Classique", "destino_principal": "Rome",
               "descricao": "5 nuits à la découverte du Colisée, du Vatican et de la gastronomie italienne authentique.",
               "itens_incluidos": ["Hôtel central", "Tour guidé", "Cours de cuisine", "Vatican coupe-file"]},
    },
    # Bali Espiritual
    8: {
        "en": {"nome": "Spiritual Bali", "destino_principal": "Bali",
               "descricao": "9 nights between temples, rice paddies and beaches. Includes a yoga retreat and surf lessons.",
               "itens_incluidos": ["Private villa", "Yoga retreat", "Surf lessons", "Temple tour"]},
        "es": {"nome": "Bali Espiritual", "destino_principal": "Bali",
               "descricao": "9 noches entre templos, arrozales y playas. Incluye retiro de yoga y clases de surf.",
               "itens_incluidos": ["Villa privada", "Retiro de yoga", "Clases de surf", "Tour de templos"]},
        "fr": {"nome": "Bali Spirituel", "destino_principal": "Bali",
               "descricao": "9 nuits entre temples, rizières et plages. Comprend une retraite yoga et des cours de surf.",
               "itens_incluidos": ["Villa privée", "Retraite yoga", "Cours de surf", "Tour des temples"]},
    },
}


def localize_destination(d: dict, lang: str) -> dict:
    """Return a copy of `d` overridden with translations for the requested locale."""
    if lang == "pt" or lang not in ("en", "es", "fr"):
        return d
    tr = DESTINATIONS.get(d["destination_id"], {}).get(lang)
    if not tr:
        return d
    out = dict(d)
    for k in ("nome", "pais", "descricao"):
        if k in tr:
            out[k] = tr[k]
    if "destaques" in tr and "destaques" in out:
        out["destaques"] = tr["destaques"]
    return out


def localize_package(p: dict, lang: str) -> dict:
    if lang == "pt" or lang not in ("en", "es", "fr"):
        return p
    tr = PACKAGES.get(p["package_id"], {}).get(lang)
    if not tr:
        return p
    out = dict(p)
    for k in ("nome", "destino_principal", "descricao"):
        if k in tr:
            out[k] = tr[k]
    if "itens_incluidos" in tr and "itens_incluidos" in out:
        out["itens_incluidos"] = tr["itens_incluidos"]
    return out
