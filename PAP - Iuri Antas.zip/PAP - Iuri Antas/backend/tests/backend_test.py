"""Backend tests for IPTrip travel site - exchange rates, AI search, checkout, listings."""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://77d9a994-cf25-4c1f-9905-237b3b8d1e5b.preview.emergentagent.com").rstrip("/")


@pytest.fixture(scope="module")
def api():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


# ---------- /api/exchange-rates ----------
class TestExchangeRates:
    def test_returns_rates_with_eur_base(self, api):
        r = api.get(f"{BASE_URL}/api/exchange-rates", timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["base"] == "EUR"
        for c in ["EUR", "USD", "GBP", "ARS"]:
            assert c in data["rates"], f"missing {c}"
        assert data["rates"]["EUR"] == 1.0
        assert "symbols" in data and data["symbols"]["EUR"] == "€"


# ---------- /api/destinos & /api/pacotes ----------
class TestListings:
    def test_destinos_list(self, api):
        r = api.get(f"{BASE_URL}/api/destinos", timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list) and len(data) > 0

    def test_pacotes_list(self, api):
        r = api.get(f"{BASE_URL}/api/pacotes", timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list) and len(data) > 0


# ---------- /api/ai-search ----------
class TestAISearch:
    def test_ai_search_returns_results(self, api):
        payload = {"query": "7 days romantic beach trip under 4000 euros", "lang": "pt"}
        r = api.post(f"{BASE_URL}/api/ai-search", json=payload, timeout=90)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data.get("status") == "ok"
        assert "destinations" in data and isinstance(data["destinations"], list)
        assert "packages" in data and isinstance(data["packages"], list)
        assert "explanation" in data

    def test_ai_search_empty_query(self, api):
        r = api.post(f"{BASE_URL}/api/ai-search", json={"query": "", "lang": "pt"}, timeout=15)
        assert r.status_code == 400


# ---------- /api/checkout ----------
class TestCheckout:
    def test_checkout_success(self, api):
        payload = {
            "nome": "TEST User",
            "email": "TEST_checkout@example.com",
            "telefone": "+351900000000",
            "card_number": "4242424242424242",
            "card_name": "TEST USER",
            "card_expiry": "12/28",
            "card_cvc": "123",
            "package_id": 1,
            "total_eur": 3200,
            "travelers": 2,
            "travel_date": "2026-05-01",
        }
        r = api.post(f"{BASE_URL}/api/checkout", json=payload, timeout=20)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["status"] == "ok"
        assert data["confirmation"].startswith("IPT-")
        assert data["card_last4"] == "4242"
        assert data["travelers"] == 2
        # total_eur should be multiplied by travelers (3200 * 2 = 6400)
        assert data["total_eur"] == 6400

    def test_checkout_invalid_card(self, api):
        payload = {
            "nome": "TEST User",
            "email": "TEST_checkout@example.com",
            "card_number": "1234",  # too short
            "card_name": "TEST USER",
            "card_expiry": "12/28",
            "card_cvc": "123",
            "package_id": 1,
            "total_eur": 1000,
            "travelers": 1,
        }
        r = api.post(f"{BASE_URL}/api/checkout", json=payload, timeout=15)
        assert r.status_code == 400
        assert "invalid_card" in r.text

    def test_checkout_missing_fields(self, api):
        r = api.post(f"{BASE_URL}/api/checkout", json={"nome": "", "email": ""}, timeout=15)
        assert r.status_code == 400

    def test_checkout_invalid_email(self, api):
        payload = {
            "nome": "TEST", "email": "bad-email", "card_number": "4242424242424242",
            "card_name": "X", "card_expiry": "12/28", "card_cvc": "123",
            "package_id": 1, "total_eur": 100, "travelers": 1,
        }
        r = api.post(f"{BASE_URL}/api/checkout", json=payload, timeout=15)
        assert r.status_code == 400
