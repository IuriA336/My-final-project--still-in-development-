"""MariaDB/MySQL database layer using PyMySQL.

Exposes the same `get_db()` / `close_db()` / `init_db()` contract that the
rest of the code relies on, but talks to MariaDB instead of SQLite.

The returned connection cursor behaves like sqlite3.Row when fetched, since
PyMySQL is configured with `cursorclass=DictCursor`. To keep the existing
route code (which uses `cursor.execute(...)` followed by `.fetchone()` /
`.fetchall()` and indexes into rows with `row["col"]`) working, we wrap
the connection in a small `DBProxy` that exposes `execute`, `executemany`,
and `commit` directly, returning a cursor that is also iterable.
"""
import os
import pymysql
from pymysql.cursors import DictCursor
from werkzeug.security import generate_password_hash, check_password_hash
from flask import g
from dotenv import load_dotenv

load_dotenv()


def _config():
    return {
        "host": os.environ.get("MYSQL_HOST", "127.0.0.1"),
        "port": int(os.environ.get("MYSQL_PORT", "3306")),
        "user": os.environ["MYSQL_USER"],
        "password": os.environ["MYSQL_PASSWORD"],
        "database": os.environ["MYSQL_DB"],
        "charset": "utf8mb4",
        "cursorclass": DictCursor,
        "autocommit": False,
    }


class DBProxy:
    """Thin wrapper that mimics the sqlite3 connection API used by the routes."""

    def __init__(self, conn):
        self.conn = conn

    def execute(self, sql, params=()):
        # Translate "?" placeholders to "%s" so existing SQL keeps working.
        sql = sql.replace("?", "%s")
        cur = self.conn.cursor()
        cur.execute(sql, params)
        cur.lastrowid = cur.lastrowid  # explicit attribute (already provided)
        return _CursorProxy(cur)

    def executemany(self, sql, seq):
        sql = sql.replace("?", "%s")
        cur = self.conn.cursor()
        cur.executemany(sql, seq)
        return _CursorProxy(cur)

    def executescript(self, script):
        # MariaDB does not accept multiple statements via the default driver
        # call. Split on `;` (statements have no embedded semicolons in our case).
        for stmt in [s.strip() for s in script.split(";") if s.strip()]:
            cur = self.conn.cursor()
            cur.execute(stmt)
            cur.close()

    def commit(self):
        self.conn.commit()

    def close(self):
        self.conn.close()


class _CursorProxy:
    """Wrap a PyMySQL cursor so row-dicts behave like sqlite3.Row (subscriptable)."""

    def __init__(self, cur):
        self._cur = cur
        self.lastrowid = cur.lastrowid

    def fetchone(self):
        return self._cur.fetchone()

    def fetchall(self):
        return self._cur.fetchall()

    def __iter__(self):
        return iter(self._cur)


def get_db():
    if "db" not in g:
        conn = pymysql.connect(**_config())
        g.db = DBProxy(conn)
    return g.db


def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        try:
            db.close()
        except Exception:
            pass


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    telefone VARCHAR(50),
    password_hash VARCHAR(255) NOT NULL,
    tipo_conta VARCHAR(50) DEFAULT 'standard',
    role VARCHAR(20) DEFAULT 'user',
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS destinations (
    destination_id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    pais VARCHAR(255) NOT NULL,
    descricao TEXT,
    preco_medio DECIMAL(10,2),
    continente VARCHAR(100),
    tipo VARCHAR(255),
    popularidade INT DEFAULT 0,
    imagem_url TEXT,
    destaque1 VARCHAR(255),
    destaque2 VARCHAR(255),
    destaque3 VARCHAR(255),
    destaque4 VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS travel_packages (
    package_id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    preco DECIMAL(10,2),
    duracao INT,
    popularidade INT DEFAULT 0,
    destino_principal VARCHAR(255),
    categoria VARCHAR(100),
    imagem_url TEXT,
    item1 VARCHAR(255),
    item2 VARCHAR(255),
    item3 VARCHAR(255),
    item4 VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    package_id INT,
    destination_id INT,
    data_reserva TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total DECIMAL(10,2),
    estado VARCHAR(50) DEFAULT 'pendente',
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dream_list (
    dream_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    destination_id INT NOT NULL,
    data_adicionado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_user_dest (user_id, destination_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (destination_id) REFERENCES destinations(destination_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_log (
    audit_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    actor_email VARCHAR(255),
    action VARCHAR(80) NOT NULL,
    entity VARCHAR(40),
    entity_id INT,
    details TEXT,
    ip VARCHAR(64),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
"""


def init_db():
    db = get_db()
    db.executescript(SCHEMA)
    db.commit()

    # Ensure `role` column exists on pre-existing installs (idempotent).
    try:
        db.execute("ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'user'")
        db.commit()
    except pymysql.err.OperationalError:
        pass  # already exists

    if db.execute("SELECT COUNT(*) AS c FROM destinations").fetchone()["c"] == 0:
        _seed_catalog(db)

    _seed_admin(db)


def _seed_admin(db):
    """Idempotent admin seed. Updates password if .env value changed."""
    email = os.environ["ADMIN_EMAIL"].strip().lower()
    plain = os.environ["ADMIN_PASSWORD"]
    name = os.environ.get("ADMIN_NAME", "Administrator")

    row = db.execute(
        "SELECT user_id, password_hash, role FROM users WHERE email=%s", (email,)
    ).fetchone()

    if row is None:
        pw_hash = generate_password_hash(plain)
        db.execute(
            "INSERT INTO users (nome, email, password_hash, role, tipo_conta) "
            "VALUES (%s, %s, %s, %s, %s)",
            (name, email, pw_hash, "admin", "admin"),
        )
        db.commit()
    else:
        updates = []
        params = []
        if not check_password_hash(row["password_hash"], plain):
            updates.append("password_hash=%s")
            params.append(generate_password_hash(plain))
        if row.get("role") != "admin":
            updates.append("role=%s")
            params.append("admin")
        if updates:
            params.append(email)
            db.execute(
                f"UPDATE users SET {', '.join(updates)} WHERE email=%s", tuple(params)
            )
            db.commit()


def _seed_catalog(db):
    destinations = [
        ("Paris", "Franca", "A cidade luz oferece romance, arte e gastronomia incomparavel. Passeie pelos Champs-Elysees, visite o Louvre e desfrute de croissants frescos em cafes charmosos.", 2500, "Europa", "cultural,romantico,luxo", 95, "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800&q=80", "Torre Eiffel", "Museu do Louvre", "Arco do Triunfo", "Notre-Dame"),
        ("Maldivas", "Maldivas", "Paraiso tropical com aguas cristalinas e resorts exclusivos. Bangalos sobre a agua, mergulho com vida marinha exotica e por do sol inesquecivel.", 5500, "Asia", "praia,romantico,luxo", 92, "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=800&q=80", "Resorts overwater", "Mergulho", "Praias paradisiacas", "Spa de luxo"),
        ("Nova York", "Estados Unidos", "A cidade que nunca dorme, repleta de cultura, arte e entretenimento. Da Broadway a Central Park, cada esquina conta uma historia.", 3000, "America", "urbano,cultural,compras", 90, "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800&q=80", "Estatua da Liberdade", "Central Park", "Times Square", "Broadway"),
        ("Toquio", "Japao", "Fusao perfeita entre tradicao milenar e tecnologia futurista. Templos antigos ao lado de arranha-ceus neon, gastronomia unica.", 3500, "Asia", "cultural,urbano,gastronomia", 88, "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800&q=80", "Templo Senso-ji", "Shibuya Crossing", "Monte Fuji", "Akihabara"),
        ("Cancun", "Mexico", "Praias paradisiacas e ruinas maias em um so lugar. Aguas turquesa, cenotes misteriosos e vida noturna vibrante.", 1800, "America", "praia,aventura,familia", 85, "https://images.unsplash.com/photo-1568402102990-bc541580b59f?w=800&q=80", "Praias de areia branca", "Ruinas Maias", "Cenotes", "Vida noturna"),
        ("Dubai", "Emirados Arabes", "Luxo e modernidade no coracao do deserto arabe. Arranha-ceus recordistas, shopping centers gigantes e experiencias unicas.", 4000, "Asia", "luxo,compras,urbano,aventura", 87, "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800&q=80", "Burj Khalifa", "Dubai Mall", "Safari no deserto", "Palm Jumeirah"),
        ("Roma", "Italia", "A cidade eterna onde a historia vive em cada rua. Coliseu, Vaticano, gelato artesanal e a dolce vita italiana.", 2200, "Europa", "cultural,romantico,gastronomia", 89, "https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=800&q=80", "Coliseu", "Vaticano", "Fontana di Trevi", "Pantheon"),
        ("Santorini", "Grecia", "Ilhas gregas com por do sol espetacular e arquitetura iconica. Casas brancas com cupulas azuis, vinhos locais e praias vulcanicas.", 2800, "Europa", "romantico,praia,luxo", 86, "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=800&q=80", "Oia ao por do sol", "Praias vulcanicas", "Vinhos locais", "Fira"),
        ("Bali", "Indonesia", "Ilha dos deuses com templos misticos, arrozais em terracos e surf de classe mundial. Espiritualidade e natureza em harmonia.", 1500, "Asia", "praia,aventura,cultural", 84, "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=800&q=80", "Templo Uluwatu", "Arrozais de Tegallalang", "Ubud", "Praias de surf"),
        ("Barcelona", "Espanha", "Arquitetura de Gaudi, praias mediterraneas e tapas incriveis. Uma cidade vibrante onde arte, cultura e festa se encontram.", 2000, "Europa", "cultural,praia,urbano,gastronomia", 83, "https://images.unsplash.com/photo-1583422409516-2895a77efded?w=800&q=80", "Sagrada Familia", "Park Guell", "Las Ramblas", "Praia de Barceloneta"),
        ("Machu Picchu", "Peru", "Cidade perdida dos Incas nas alturas dos Andes. Uma das maravilhas do mundo moderno, cheia de misterio e beleza natural.", 2100, "America", "aventura,cultural", 82, "https://images.unsplash.com/photo-1587595431973-160d0d94add1?w=800&q=80", "Cidadela Inca", "Trilha Inca", "Vale Sagrado", "Aguas Calientes"),
        ("Londres", "Reino Unido", "Capital britanica com historia milenar, museus de classe mundial e vida cultural vibrante. Do Big Ben a Camden Town.", 2700, "Europa", "cultural,urbano,compras", 88, "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=800&q=80", "Big Ben", "British Museum", "Tower Bridge", "Buckingham Palace"),
    ]
    db.executemany("""
        INSERT INTO destinations (nome, pais, descricao, preco_medio, continente, tipo, popularidade, imagem_url, destaque1, destaque2, destaque3, destaque4)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, destinations)

    packages = [
        ("Romance em Paris", "7 noites em hotel 4 estrelas com vista para a Torre Eiffel, jantar em restaurante Michelin e cruzeiro no Sena.", 3200, 7, 95, "Paris", "romantico", "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=800&q=80", "Voo ida e volta", "Hotel 4 estrelas", "Jantar romantico", "Cruzeiro no Sena"),
        ("Lua de Mel nas Maldivas", "10 noites em resort overwater all-inclusive com spa, mergulho e jantar privado na praia.", 8500, 10, 92, "Maldivas", "romantico", "https://images.unsplash.com/photo-1573843981267-be1999ff37cd?w=800&q=80", "Resort overwater", "All-inclusive", "Spa para casal", "Jantar na praia"),
        ("Aventura em Toquio", "8 noites explorando templos, bairros neon, gastronomia e cultura pop japonesa.", 4200, 8, 88, "Toquio", "cultural", "https://images.unsplash.com/photo-1536098561742-ca998e48cbcc?w=800&q=80", "Hotel em Shinjuku", "Japan Rail Pass", "Tour gastronomico", "Dia no Monte Fuji"),
        ("New York Explorer", "5 noites em Manhattan com ingressos para Broadway, visita a museus e tour de helicóptero.", 3800, 5, 87, "Nova York", "urbano", "https://images.unsplash.com/photo-1485871981521-5b1fd3805eee?w=800&q=80", "Hotel em Manhattan", "Ingressos Broadway", "Museus incluidos", "Tour helicoptero"),
        ("Praias de Cancun", "7 noites all-inclusive em resort 5 estrelas com excursoes a ruinas maias e cenotes.", 2400, 7, 85, "Cancun", "praia", "https://images.unsplash.com/photo-1510097467424-192d713fd8b2?w=800&q=80", "Resort 5 estrelas", "All-inclusive", "Tour ruinas maias", "Cenotes"),
        ("Dubai Luxury", "6 noites de luxo com safari no deserto, Burj Khalifa e experiencias exclusivas.", 5500, 6, 86, "Dubai", "luxo", "https://images.unsplash.com/photo-1518684079-3c830dcef090?w=800&q=80", "Hotel 5 estrelas", "Safari no deserto", "Burj Khalifa VIP", "Jantar no Atmosphere"),
        ("Roma Classica", "5 noites descobrindo o Coliseu, Vaticano e a gastronomia italiana autentica.", 2100, 5, 84, "Roma", "cultural", "https://images.unsplash.com/photo-1529260830199-42c24126f198?w=800&q=80", "Hotel no centro", "Tour guiado", "Aula de culinaria", "Vaticano sem fila"),
        ("Bali Espiritual", "9 noites entre templos, arrozais e praias. Inclui retiro de yoga e aulas de surf.", 2000, 9, 83, "Bali", "aventura", "https://images.unsplash.com/photo-1555400038-63f5ba517a47?w=800&q=80", "Villa privada", "Retiro de yoga", "Aulas de surf", "Tour de templos"),
    ]
    db.executemany("""
        INSERT INTO travel_packages (nome, descricao, preco, duracao, popularidade, destino_principal, categoria, imagem_url, item1, item2, item3, item4)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, packages)
    db.commit()
