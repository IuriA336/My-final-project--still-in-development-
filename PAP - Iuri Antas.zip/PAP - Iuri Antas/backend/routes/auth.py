import os
import time
from collections import defaultdict
from threading import Lock
from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from db import get_db

auth_bp = Blueprint("auth", __name__)

MAX_ATTEMPTS = int(os.environ.get("LOGIN_MAX_ATTEMPTS", "5"))
BLOCK_SECONDS = int(os.environ.get("LOGIN_BLOCK_MINUTES", "15")) * 60

# {key: [(timestamp,...), block_until]}  key = client_ip + email
_attempts: dict = defaultdict(list)
_blocked: dict = {}
_lock = Lock()


def _client_key(email: str) -> str:
    ip = request.headers.get("X-Forwarded-For", request.remote_addr or "?").split(",")[0].strip()
    return f"{ip}|{email}"


def _check_rate_limit(email: str):
    key = _client_key(email)
    now = time.time()
    with _lock:
        # cleanup
        blocked_until = _blocked.get(key)
        if blocked_until and now < blocked_until:
            return int(blocked_until - now)
        if blocked_until and now >= blocked_until:
            _blocked.pop(key, None)
            _attempts.pop(key, None)
        # prune old attempts (older than block window)
        _attempts[key] = [t for t in _attempts[key] if now - t < BLOCK_SECONDS]
        return 0


def _register_failure(email: str):
    key = _client_key(email)
    now = time.time()
    with _lock:
        _attempts[key].append(now)
        if len(_attempts[key]) >= MAX_ATTEMPTS:
            _blocked[key] = now + BLOCK_SECONDS


def _reset(email: str):
    key = _client_key(email)
    with _lock:
        _attempts.pop(key, None)
        _blocked.pop(key, None)


@auth_bp.post("/api/register")
def register():
    data = request.json or {}
    nome = data.get("nome")
    email = (data.get("email") or "").strip().lower()
    telefone = data.get("telefone", "")
    password = data.get("password")

    if not nome or not email or not password:
        return jsonify({"status": "error", "message": "Dados incompletos"}), 400

    db = get_db()
    existing = db.execute("SELECT user_id FROM users WHERE email=?", (email,)).fetchone()
    if existing:
        return jsonify({"status": "error", "message": "Email ja registado"}), 400

    password_hash = generate_password_hash(password)
    cursor = db.execute(
        "INSERT INTO users (nome, email, telefone, password_hash) VALUES (?, ?, ?, ?)",
        (nome, email, telefone, password_hash),
    )
    db.commit()

    return jsonify({"status": "ok", "user_id": cursor.lastrowid})


@auth_bp.post("/api/login")
def login():
    data = request.json or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not email or not password:
        return jsonify({"status": "error", "message": "Dados incompletos"}), 400

    retry_after = _check_rate_limit(email)
    if retry_after > 0:
        minutes = max(1, retry_after // 60)
        return jsonify({
            "status": "error",
            "message": f"Demasiadas tentativas. Tente novamente em {minutes} min.",
            "retry_after_seconds": retry_after,
        }), 429

    db = get_db()
    user = db.execute(
        "SELECT user_id, password_hash, nome, role FROM users WHERE email=?", (email,)
    ).fetchone()

    if not user or not check_password_hash(user["password_hash"], password):
        _register_failure(email)
        return jsonify({"status": "error", "message": "Credenciais invalidas"}), 401

    _reset(email)
    role = user.get("role") or "user"
    return jsonify({
        "status": "ok",
        "user_id": user["user_id"],
        "nome": user["nome"],
        "role": role,
        "is_admin": role == "admin",
    })
