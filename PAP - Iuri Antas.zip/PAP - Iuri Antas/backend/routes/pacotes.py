from flask import Blueprint, jsonify, request
from db import get_db
from catalog_i18n import localize_package

pacotes_bp = Blueprint("pacotes", __name__)


def _row_to_pacote(r):
    p = dict(r)
    p["itens_incluidos"] = [i for i in [p.pop("item1", None), p.pop("item2", None),
                                         p.pop("item3", None), p.pop("item4", None)] if i]
    return p


@pacotes_bp.get("/api/pacotes")
def listar_pacotes():
    lang = request.args.get("lang", "pt")
    db = get_db()
    rows = db.execute("""
        SELECT package_id, nome, descricao, preco, duracao,
               popularidade, destino_principal, categoria, imagem_url,
               item1, item2, item3, item4
        FROM travel_packages
        ORDER BY popularidade DESC
    """).fetchall()
    return jsonify([localize_package(_row_to_pacote(r), lang) for r in rows])


@pacotes_bp.get("/api/pacotes/<int:package_id>")
def detalhes_pacote(package_id):
    lang = request.args.get("lang", "pt")
    db = get_db()
    row = db.execute("""
        SELECT package_id, nome, descricao, preco, duracao,
               popularidade, destino_principal, categoria, imagem_url,
               item1, item2, item3, item4
        FROM travel_packages
        WHERE package_id=?
    """, (package_id,)).fetchone()

    if not row:
        return jsonify({"error": "Pacote nao encontrado"}), 404

    return jsonify(localize_package(_row_to_pacote(row), lang))


@pacotes_bp.get("/api/pacotes/filtrar")
def filtrar_pacotes():
    lang = request.args.get("lang", "pt")
    destino = request.args.get("destino")
    preco = request.args.get("preco")
    duracao = request.args.get("duracao")
    categoria = request.args.get("categoria")

    db = get_db()
    query = """
        SELECT package_id, nome, descricao, preco, duracao,
               popularidade, destino_principal, categoria, imagem_url,
               item1, item2, item3, item4
        FROM travel_packages WHERE 1=1
    """
    params = []

    if destino:
        query += " AND destino_principal=?"
        params.append(destino)
    if categoria:
        query += " AND categoria=?"
        params.append(categoria)
    if preco:
        ranges = {
            "low": " AND preco <= 2000",
            "medium": " AND preco BETWEEN 2000 AND 4000",
            "high": " AND preco BETWEEN 4000 AND 6000",
            "premium": " AND preco >= 6000",
        }
        query += ranges.get(preco, "")
    if duracao:
        dur_ranges = {
            "curta": " AND duracao <= 5",
            "media": " AND duracao BETWEEN 6 AND 8",
            "longa": " AND duracao > 8",
        }
        query += dur_ranges.get(duracao, "")

    query += " ORDER BY popularidade DESC"
    rows = db.execute(query, params).fetchall()
    return jsonify([localize_package(_row_to_pacote(r), lang) for r in rows])
