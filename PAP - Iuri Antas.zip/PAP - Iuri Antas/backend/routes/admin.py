"""Admin-only endpoints. Auth is checked via the X-User-Id header — the
endpoint resolves the user against the database and verifies role == 'admin'.

Keeps the lightweight session-less pattern already used by the rest of the
app, while preventing a non-admin client from forging admin requests
(the role is read from the DB, not from the request)."""
import json
from functools import wraps
from flask import Blueprint, request, jsonify, g
from db import get_db

admin_bp = Blueprint("admin", __name__, url_prefix="/api/admin")


def _audit(action, entity=None, entity_id=None, details=None):
    """Insert an audit log row for the current admin action."""
    actor = getattr(g, "admin_user", None) or {}
    ip = (request.headers.get("X-Forwarded-For", request.remote_addr or "?") or "?").split(",")[0].strip()
    db = get_db()
    db.execute(
        "INSERT INTO audit_log (user_id, actor_email, action, entity, entity_id, details, ip) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (actor.get("user_id"), actor.get("email"), action, entity, entity_id,
         json.dumps(details, ensure_ascii=False) if details else None, ip),
    )
    db.commit()


def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user_id = request.headers.get("X-User-Id")
        if not user_id:
            return jsonify({"status": "error", "message": "Auth required"}), 401
        try:
            user_id = int(user_id)
        except (TypeError, ValueError):
            return jsonify({"status": "error", "message": "Auth invalid"}), 401
        db = get_db()
        user = db.execute(
            "SELECT user_id, email, role FROM users WHERE user_id=?", (user_id,)
        ).fetchone()
        if not user or user.get("role") != "admin":
            return jsonify({"status": "error", "message": "Forbidden"}), 403
        g.admin_user = {"user_id": user["user_id"], "email": user["email"]}
        return fn(*args, **kwargs)
    return wrapper


# ============ STATS ============
@admin_bp.get("/stats")
@admin_required
def stats():
    db = get_db()
    users_total = db.execute("SELECT COUNT(*) AS c FROM users WHERE role!='admin'").fetchone()["c"]
    bookings_total = db.execute("SELECT COUNT(*) AS c FROM bookings").fetchone()["c"]
    revenue = db.execute(
        "SELECT COALESCE(SUM(total),0) AS s FROM bookings WHERE estado='confirmada'"
    ).fetchone()["s"]
    destinations_total = db.execute("SELECT COUNT(*) AS c FROM destinations").fetchone()["c"]
    packages_total = db.execute("SELECT COUNT(*) AS c FROM travel_packages").fetchone()["c"]

    top_dest = db.execute("""
        SELECT d.nome, d.pais, COUNT(b.booking_id) AS reservas
        FROM destinations d
        LEFT JOIN bookings b ON b.destination_id = d.destination_id
        GROUP BY d.destination_id, d.nome, d.pais
        ORDER BY reservas DESC, d.popularidade DESC
        LIMIT 5
    """).fetchall()

    top_pkg = db.execute("""
        SELECT p.nome, p.destino_principal, COUNT(b.booking_id) AS reservas
        FROM travel_packages p
        LEFT JOIN bookings b ON b.package_id = p.package_id
        GROUP BY p.package_id, p.nome, p.destino_principal
        ORDER BY reservas DESC, p.popularidade DESC
        LIMIT 5
    """).fetchall()

    return jsonify({
        "users_total": users_total,
        "bookings_total": bookings_total,
        "revenue_eur": float(revenue or 0),
        "destinations_total": destinations_total,
        "packages_total": packages_total,
        "top_destinations": [dict(r) for r in top_dest],
        "top_packages": [dict(r) for r in top_pkg],
    })


# ============ BOOKINGS ============
@admin_bp.get("/bookings")
@admin_required
def list_bookings():
    db = get_db()
    rows = db.execute("""
        SELECT b.booking_id, b.data_reserva, b.total, b.estado,
               u.nome AS cliente, u.email, u.telefone,
               COALESCE(p.nome, d.nome) AS item,
               CASE WHEN b.package_id IS NOT NULL THEN 'pacote' ELSE 'destino' END AS tipo
        FROM bookings b
        JOIN users u ON u.user_id = b.user_id
        LEFT JOIN travel_packages p ON p.package_id = b.package_id
        LEFT JOIN destinations d ON d.destination_id = b.destination_id
        ORDER BY b.data_reserva DESC
    """).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        if d.get("data_reserva"):
            d["data_reserva"] = d["data_reserva"].isoformat()
        d["total"] = float(d["total"] or 0)
        out.append(d)
    return jsonify(out)


@admin_bp.patch("/bookings/<int:booking_id>")
@admin_required
def update_booking(booking_id):
    data = request.json or {}
    estado = data.get("estado")
    if estado not in ("pendente", "confirmada", "cancelada"):
        return jsonify({"status": "error", "message": "Estado invalido"}), 400
    db = get_db()
    db.execute("UPDATE bookings SET estado=? WHERE booking_id=?", (estado, booking_id))
    db.commit()
    _audit("booking.update_status", "booking", booking_id, {"estado": estado})
    return jsonify({"status": "ok"})


@admin_bp.delete("/bookings/<int:booking_id>")
@admin_required
def delete_booking(booking_id):
    db = get_db()
    db.execute("DELETE FROM bookings WHERE booking_id=?", (booking_id,))
    db.commit()
    _audit("booking.delete", "booking", booking_id)
    return jsonify({"status": "ok"})


# ============ USERS ============
@admin_bp.get("/users")
@admin_required
def list_users():
    db = get_db()
    rows = db.execute(
        "SELECT user_id, nome, email, telefone, role, tipo_conta, data_criacao "
        "FROM users ORDER BY data_criacao DESC"
    ).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        if d.get("data_criacao"):
            d["data_criacao"] = d["data_criacao"].isoformat()
        out.append(d)
    return jsonify(out)


# ============ DESTINATIONS CRUD ============
def _dest_payload(data):
    return (
        data.get("nome"), data.get("pais"), data.get("descricao"),
        data.get("preco_medio"), data.get("continente"), data.get("tipo"),
        data.get("popularidade") or 0, data.get("imagem_url"),
        data.get("destaque1"), data.get("destaque2"),
        data.get("destaque3"), data.get("destaque4"),
    )


@admin_bp.post("/destinations")
@admin_required
def create_destination():
    data = request.json or {}
    if not data.get("nome") or not data.get("pais"):
        return jsonify({"status": "error", "message": "Nome e pais obrigatorios"}), 400
    db = get_db()
    cur = db.execute("""
        INSERT INTO destinations (nome, pais, descricao, preco_medio, continente, tipo,
                                  popularidade, imagem_url, destaque1, destaque2, destaque3, destaque4)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, _dest_payload(data))
    db.commit()
    _audit("destination.create", "destination", cur.lastrowid, {"nome": data.get("nome")})
    return jsonify({"status": "ok", "destination_id": cur.lastrowid})


@admin_bp.put("/destinations/<int:destination_id>")
@admin_required
def update_destination(destination_id):
    data = request.json or {}
    db = get_db()
    db.execute("""
        UPDATE destinations SET nome=?, pais=?, descricao=?, preco_medio=?, continente=?,
            tipo=?, popularidade=?, imagem_url=?, destaque1=?, destaque2=?, destaque3=?, destaque4=?
        WHERE destination_id=?
    """, _dest_payload(data) + (destination_id,))
    db.commit()
    _audit("destination.update", "destination", destination_id, {"nome": data.get("nome")})
    return jsonify({"status": "ok"})


@admin_bp.delete("/destinations/<int:destination_id>")
@admin_required
def delete_destination(destination_id):
    db = get_db()
    db.execute("DELETE FROM destinations WHERE destination_id=?", (destination_id,))
    db.commit()
    _audit("destination.delete", "destination", destination_id)
    return jsonify({"status": "ok"})


# ============ PACKAGES CRUD ============
def _pkg_payload(data):
    return (
        data.get("nome"), data.get("descricao"), data.get("preco"),
        data.get("duracao") or 1, data.get("popularidade") or 0,
        data.get("destino_principal"), data.get("categoria"), data.get("imagem_url"),
        data.get("item1"), data.get("item2"), data.get("item3"), data.get("item4"),
    )


@admin_bp.post("/packages")
@admin_required
def create_package():
    data = request.json or {}
    if not data.get("nome"):
        return jsonify({"status": "error", "message": "Nome obrigatorio"}), 400
    db = get_db()
    cur = db.execute("""
        INSERT INTO travel_packages (nome, descricao, preco, duracao, popularidade,
                                     destino_principal, categoria, imagem_url, item1, item2, item3, item4)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, _pkg_payload(data))
    db.commit()
    _audit("package.create", "package", cur.lastrowid, {"nome": data.get("nome")})
    return jsonify({"status": "ok", "package_id": cur.lastrowid})


@admin_bp.put("/packages/<int:package_id>")
@admin_required
def update_package(package_id):
    data = request.json or {}
    db = get_db()
    db.execute("""
        UPDATE travel_packages SET nome=?, descricao=?, preco=?, duracao=?, popularidade=?,
            destino_principal=?, categoria=?, imagem_url=?, item1=?, item2=?, item3=?, item4=?
        WHERE package_id=?
    """, _pkg_payload(data) + (package_id,))
    db.commit()
    _audit("package.update", "package", package_id, {"nome": data.get("nome")})
    return jsonify({"status": "ok"})


@admin_bp.delete("/packages/<int:package_id>")
@admin_required
def delete_package(package_id):
    db = get_db()
    db.execute("DELETE FROM travel_packages WHERE package_id=?", (package_id,))
    db.commit()
    _audit("package.delete", "package", package_id)
    return jsonify({"status": "ok"})


# ============ AUDIT LOG ============
@admin_bp.get("/audit")
@admin_required
def list_audit():
    limit = min(int(request.args.get("limit", 200)), 500)
    db = get_db()
    rows = db.execute(
        "SELECT audit_id, actor_email, action, entity, entity_id, details, ip, created_at "
        "FROM audit_log ORDER BY created_at DESC LIMIT ?", (limit,)
    ).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        if d.get("created_at"):
            d["created_at"] = d["created_at"].isoformat()
        out.append(d)
    return jsonify(out)
