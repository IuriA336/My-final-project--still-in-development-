"""Mock checkout endpoint - validates form and creates a booking record."""
from flask import Blueprint, request, jsonify
from db import get_db
import re
import uuid

checkout_bp = Blueprint("checkout", __name__)


@checkout_bp.post("/api/checkout")
def checkout():
    data = request.json or {}

    nome = (data.get("nome") or "").strip()
    email = (data.get("email") or "").strip()
    telefone = (data.get("telefone") or "").strip()
    card_number = re.sub(r"\s+", "", str(data.get("card_number") or ""))
    card_name = (data.get("card_name") or "").strip()
    card_expiry = (data.get("card_expiry") or "").strip()
    card_cvc = (data.get("card_cvc") or "").strip()

    package_id = data.get("package_id")
    destination_id = data.get("destination_id")
    total_eur = float(data.get("total_eur") or 0)
    travelers = int(data.get("travelers") or 1)
    travel_date = (data.get("travel_date") or "").strip()
    user_id = data.get("user_id")

    # basic validations
    if not nome or not email or not card_name:
        return jsonify({"status": "error", "message": "missing_fields"}), 400
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        return jsonify({"status": "error", "message": "invalid_email"}), 400
    if not re.match(r"^\d{13,19}$", card_number):
        return jsonify({"status": "error", "message": "invalid_card"}), 400
    if not re.match(r"^\d{2}/\d{2}$", card_expiry):
        return jsonify({"status": "error", "message": "invalid_expiry"}), 400
    if not re.match(r"^\d{3,4}$", card_cvc):
        return jsonify({"status": "error", "message": "invalid_cvc"}), 400
    if total_eur <= 0:
        return jsonify({"status": "error", "message": "invalid_total"}), 400

    db = get_db()
    final_user_id = user_id

    # Guest checkout: create or reuse a guest user keyed by email
    if not final_user_id:
        existing = db.execute("SELECT user_id FROM users WHERE email=?", (email,)).fetchone()
        if existing:
            final_user_id = existing["user_id"]
        else:
            cursor = db.execute(
                "INSERT INTO users (nome, email, telefone, password_hash, tipo_conta) VALUES (?, ?, ?, ?, ?)",
                (nome, email, telefone, "guest_" + uuid.uuid4().hex, "guest"),
            )
            final_user_id = cursor.lastrowid

    total_value = total_eur * travelers

    cursor = db.execute(
        "INSERT INTO bookings (user_id, package_id, destination_id, total, estado) VALUES (?, ?, ?, ?, ?)",
        (final_user_id, package_id, destination_id, total_value, "confirmada"),
    )
    db.commit()

    confirmation = "IPT-" + uuid.uuid4().hex[:8].upper()

    return jsonify({
        "status": "ok",
        "booking_id": cursor.lastrowid,
        "confirmation": confirmation,
        "total_eur": total_value,
        "travelers": travelers,
        "travel_date": travel_date,
        "card_last4": card_number[-4:],
    })
