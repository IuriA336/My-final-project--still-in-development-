"""Heuristic local search - no LLM, no external API, instant and free.

Extracts intent from the natural-language query (budget, type, duration, continent,
keywords) and ranks the catalog by relevance.
"""
import re
import unicodedata
from flask import Blueprint, request, jsonify
from db import get_db
from catalog_i18n import localize_destination, localize_package

ai_search_bp = Blueprint("ai_search", __name__)


def _strip(s: str) -> str:
    if not s:
        return ""
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.lower()


# Map keywords (any language) → canonical type stored in DB.
# DB stores tipo as comma-separated: cultural, praia, romantico, aventura, luxo, urbano, gastronomia
TYPE_KEYWORDS = {
    "praia": ["praia", "playa", "beach", "plage", "tropical", "ilha", "island", "isla", "ile", "mar", "sea", "mer"],
    "romantico": ["romantic", "romantico", "romantique", "lua de mel", "honeymoon", "luna de miel", "casal", "couple"],
    "cultural": ["cultural", "cultura", "culture", "historia", "history", "historique", "historico", "monumento", "museu", "museum", "patrimonio"],
    "aventura": ["aventura", "adventure", "trilho", "trek", "trekking", "natureza", "nature", "selva", "jungle", "montanha", "mountain", "montana", "rafting", "safari"],
    "luxo": ["luxo", "luxury", "lujo", "luxe", "premium", "exclusivo", "exclusive", "5 estrelas", "five stars", "spa", "resort"],
    "urbano": ["urbano", "urban", "cidade", "city", "ville", "metropole", "metropoli", "ciudad"],
    "gastronomia": ["gastronomia", "gastronomy", "gastronomie", "comida", "food", "culinar", "wine", "vinho", "cuisine", "restaurante", "restaurant"],
}

CONTINENT_KEYWORDS = {
    "Europa": ["europa", "europe", "european", "europe"],
    "Asia": ["asia", "asiatic", "asiatique", "asian"],
    "America do Norte": ["america do norte", "north america", "amerique du nord", "norteamerica", "estados unidos", "usa", "eua"],
    "America do Sul": ["america do sul", "south america", "amerique du sud", "sudamerica", "latin"],
    "Africa": ["africa", "african", "africain", "africana"],
    "Oceania": ["oceania", "oceanie", "oceania"],
}

CURRENCY_RATES = {"EUR": 1.0, "USD": 1.08, "GBP": 0.86, "ARS": 1100.0}
CURRENCY_TOKENS = {
    "EUR": ["€", "eur", "euro", "euros"],
    "USD": ["$", "usd", "dolar", "dollar", "dollars", "dolares"],
    "GBP": ["£", "gbp", "libra", "libras", "pound", "pounds"],
    "ARS": ["ars", "peso", "pesos"],
}


def _extract_budget_eur(q_norm: str):
    """Return budget in EUR or None."""
    # find a number (with optional thousands separator) optionally followed by currency token
    pattern = re.compile(r"(?P<num>\d{4,}|\d{1,3}(?:[\.\s,]\d{3})+|\d+)\s*(?P<cur>€|\$|£|euros?|eur|usd|dolar|dollar|gbp|libra|pound|ars|peso)?", re.IGNORECASE)
    candidates = []
    for m in pattern.finditer(q_norm):
        raw = m.group("num").replace(" ", "").replace(".", "").replace(",", "")
        try:
            val = float(raw)
        except ValueError:
            continue
        if val < 50:  # too small to be a budget (probably duration)
            continue
        cur_tok = (m.group("cur") or "").lower()
        cur = "EUR"
        for code, toks in CURRENCY_TOKENS.items():
            if cur_tok in toks:
                cur = code
                break
        # convert to EUR
        rate = CURRENCY_RATES.get(cur, 1.0)
        val_eur = val / rate
        candidates.append(val_eur)
    return max(candidates) if candidates else None


def _extract_duration(q_norm: str):
    """Return number of nights wanted, or None."""
    m = re.search(r"(\d{1,2})\s*(noites|nights|nuits|noches|dias|days|jours|días|d[ií]as)", q_norm)
    if m:
        n = int(m.group(1))
        # if "dias/days" → noites = dias - 1 (approximate)
        unit = m.group(2)
        if any(u in unit for u in ["dia", "day", "jour"]):
            return max(1, n - 1)
        return n
    return None


def _extract_types(q_norm: str):
    found = set()
    for canonical, kws in TYPE_KEYWORDS.items():
        for kw in kws:
            if kw in q_norm:
                found.add(canonical)
                break
    return found


def _extract_continent(q_norm: str):
    for canonical, kws in CONTINENT_KEYWORDS.items():
        for kw in kws:
            if kw in q_norm:
                return canonical
    return None


def _score_destination(d, intent):
    score = 0
    tipo_norm = _strip(d.get("tipo") or "")
    nome_norm = _strip(d.get("nome") or "")
    pais_norm = _strip(d.get("pais") or "")
    desc_norm = _strip(d.get("descricao") or "")
    continente = d.get("continente") or ""

    # Type match (heavy weight)
    for t in intent["types"]:
        if t in tipo_norm:
            score += 40

    # Continent match
    if intent["continent"] and continente == intent["continent"]:
        score += 25

    # Country/name keyword matches
    for kw in intent["raw_keywords"]:
        if len(kw) < 4:
            continue
        if kw in nome_norm or kw in pais_norm:
            score += 30
        elif kw in desc_norm:
            score += 8

    # Budget: prefer items <= budget
    if intent["budget_eur"]:
        if d["preco_medio"] <= intent["budget_eur"]:
            score += 20
            # bonus if uses most of budget (between 50-100%)
            if d["preco_medio"] >= intent["budget_eur"] * 0.5:
                score += 10
        else:
            # penalty proportional to overage
            score -= min(30, (d["preco_medio"] - intent["budget_eur"]) / intent["budget_eur"] * 40)

    # Small popularity tie-breaker
    score += (d.get("popularidade") or 0) * 0.05
    return score


def _score_package(p, intent):
    score = 0
    cat_norm = _strip(p.get("categoria") or "")
    nome_norm = _strip(p.get("nome") or "")
    dest_norm = _strip(p.get("destino_principal") or "")
    desc_norm = _strip(p.get("descricao") or "")

    for t in intent["types"]:
        if t in cat_norm:
            score += 40

    for kw in intent["raw_keywords"]:
        if len(kw) < 4:
            continue
        if kw in nome_norm or kw in dest_norm:
            score += 30
        elif kw in desc_norm:
            score += 8

    if intent["budget_eur"]:
        if p["preco"] <= intent["budget_eur"]:
            score += 20
            if p["preco"] >= intent["budget_eur"] * 0.5:
                score += 10
        else:
            score -= min(30, (p["preco"] - intent["budget_eur"]) / intent["budget_eur"] * 40)

    if intent["duration_nights"]:
        diff = abs(p["duracao"] - intent["duration_nights"])
        if diff == 0:
            score += 30
        elif diff <= 2:
            score += 15
        elif diff > 5:
            score -= 10

    score += (p.get("popularidade") or 0) * 0.05
    return score


def _build_explanation(intent, lang):
    parts = []
    L = lang if lang in ("pt", "en", "es", "fr") else "pt"
    labels = {
        "pt": {"budget": "orçamento até", "types": "estilo", "duration": "duração de", "nights": "noites", "continent": "no continente"},
        "en": {"budget": "budget up to", "types": "style", "duration": "duration of", "nights": "nights", "continent": "in"},
        "es": {"budget": "presupuesto hasta", "types": "estilo", "duration": "duración de", "nights": "noches", "continent": "en"},
        "fr": {"budget": "budget jusqu'à", "types": "style", "duration": "durée de", "nights": "nuits", "continent": "en"},
    }
    intro = {"pt": "Selecionei opções com", "en": "I picked options with", "es": "Seleccioné opciones con", "fr": "J'ai choisi des options avec"}
    empty = {
        "pt": "Não encontrei viagens que correspondam exatamente. Tente alargar o orçamento ou alterar o estilo.",
        "en": "I couldn't find trips that match exactly. Try increasing the budget or changing the style.",
        "es": "No encontré viajes que coincidan exactamente. Intenta aumentar el presupuesto o cambiar el estilo.",
        "fr": "Je n'ai pas trouvé de voyages correspondant exactement. Essayez d'augmenter le budget ou de changer de style.",
    }
    lab = labels[L]
    if intent["types"]:
        parts.append(lab["types"] + " " + "/".join(sorted(intent["types"])))
    if intent["budget_eur"]:
        parts.append(lab["budget"] + " €" + str(int(intent["budget_eur"])))
    if intent["duration_nights"]:
        parts.append(lab["duration"] + " " + str(intent["duration_nights"]) + " " + lab["nights"])
    if intent["continent"]:
        parts.append(lab["continent"] + " " + intent["continent"])

    if not parts:
        return empty[L]
    return intro[L] + " " + ", ".join(parts) + "."


@ai_search_bp.post("/api/ai-search")
def ai_search():
    data = request.json or {}
    query = (data.get("query") or "").strip()
    lang = data.get("lang", "pt")
    if not query:
        return jsonify({"status": "error", "message": "Query vazia"}), 400

    q_norm = _strip(query)

    intent = {
        "budget_eur": _extract_budget_eur(q_norm),
        "duration_nights": _extract_duration(q_norm),
        "types": _extract_types(q_norm),
        "continent": _extract_continent(q_norm),
        "raw_keywords": [w for w in re.findall(r"[a-z0-9]+", q_norm) if w not in {
            "com", "para", "uma", "que", "and", "the", "with", "for", "from", "in", "on",
            "dias", "noites", "days", "nights", "viagem", "trip", "voyage", "viaje",
            "euros", "euro", "dolares", "dollars", "ars", "eur", "usd", "gbp"
        }],
    }

    db = get_db()
    destinos = [dict(r) for r in db.execute("""
        SELECT destination_id, nome, pais, descricao, preco_medio, continente,
               tipo, popularidade, imagem_url, destaque1, destaque2, destaque3, destaque4
        FROM destinations
    """).fetchall()]
    pacotes = [dict(r) for r in db.execute("""
        SELECT package_id, nome, descricao, preco, duracao, popularidade,
               destino_principal, categoria, imagem_url, item1, item2, item3, item4
        FROM travel_packages
    """).fetchall()]

    # Score
    dest_scored = [(d, _score_destination(d, intent)) for d in destinos]
    pkg_scored = [(p, _score_package(p, intent)) for p in pacotes]

    # Decide minimum score threshold
    has_intent = bool(intent["types"] or intent["budget_eur"] or intent["duration_nights"]
                      or intent["continent"] or intent["raw_keywords"])
    threshold = 15 if has_intent else 0

    dest_scored.sort(key=lambda x: x[1], reverse=True)
    pkg_scored.sort(key=lambda x: x[1], reverse=True)

    dest_top = [d for d, s in dest_scored if s >= threshold][:6]
    pkg_top = [p for p, s in pkg_scored if s >= threshold][:6]

    # If literally nothing matched, return top popular items so user still has something
    if not dest_top and not pkg_top:
        dest_top = sorted(destinos, key=lambda d: d.get("popularidade") or 0, reverse=True)[:4]
        pkg_top = sorted(pacotes, key=lambda p: p.get("popularidade") or 0, reverse=True)[:4]

    # Reshape destaques + items
    for d in dest_top:
        d["destaques"] = [h for h in [d.pop("destaque1", None), d.pop("destaque2", None),
                                       d.pop("destaque3", None), d.pop("destaque4", None)] if h]
    for p in pkg_top:
        p["itens_incluidos"] = [i for i in [p.pop("item1", None), p.pop("item2", None),
                                             p.pop("item3", None), p.pop("item4", None)] if i]

    dest_top = [localize_destination(d, lang) for d in dest_top]
    pkg_top = [localize_package(p, lang) for p in pkg_top]

    return jsonify({
        "status": "ok",
        "destinations": dest_top,
        "packages": pkg_top,
        "explanation": _build_explanation(intent, lang),
        "summary": "",
    })
