"""Currency exchange rates - uses free open.er-api.com which requires no key."""
from flask import Blueprint, jsonify
import requests
import time

currency_bp = Blueprint("currency", __name__)

# in-memory cache (1 hour TTL)
_CACHE = {"data": None, "ts": 0}
_TTL = 3600
_SUPPORTED = ["EUR", "USD", "GBP", "ARS"]

# Fallback rates in case the external API is unreachable (relative to 1 EUR).
_FALLBACK = {"EUR": 1.0, "USD": 1.08, "GBP": 0.86, "ARS": 1100.0}


def _fetch_rates():
    now = time.time()
    if _CACHE["data"] and now - _CACHE["ts"] < _TTL:
        return _CACHE["data"]

    try:
        r = requests.get("https://open.er-api.com/v6/latest/EUR", timeout=6)
        if r.ok:
            payload = r.json()
            if payload.get("result") == "success":
                rates_all = payload.get("rates", {})
                rates = {c: rates_all.get(c) for c in _SUPPORTED if c in rates_all}
                if "EUR" not in rates:
                    rates["EUR"] = 1.0
                if all(c in rates for c in _SUPPORTED):
                    _CACHE["data"] = rates
                    _CACHE["ts"] = now
                    return rates
    except Exception:
        pass

    return _FALLBACK


@currency_bp.get("/api/exchange-rates")
def exchange_rates():
    rates = _fetch_rates()
    return jsonify({
        "base": "EUR",
        "rates": rates,
        "supported": _SUPPORTED,
        "symbols": {"EUR": "€", "USD": "$", "GBP": "£", "ARS": "$"},
        "codes": {"EUR": "EUR", "USD": "USD", "GBP": "GBP", "ARS": "ARS"},
    })
