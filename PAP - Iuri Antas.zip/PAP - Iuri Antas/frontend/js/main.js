// ===================================
// Main JavaScript - IPTrip
// ===================================
const API = window.location.origin + "/api";

// ===============================
// NOTIFICATION SYSTEM
// ===============================
function showNotification(message, type) {
    var container = document.getElementById("notificationContainer");
    if (!container) return;
    var notif = document.createElement("div");
    notif.className = "notification notification-" + type;
    var icons = { success: "check-circle", error: "exclamation-circle", info: "info-circle" };
    notif.innerHTML =
        '<i class="fas fa-' + (icons[type] || "info-circle") + '"></i>' +
        '<span>' + message + '</span>' +
        '<button onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>';
    container.appendChild(notif);
    setTimeout(function () { notif.classList.add("show"); }, 10);
    setTimeout(function () { notif.classList.remove("show"); setTimeout(function () { notif.remove(); }, 300); }, 4000);
}
window.showNotification = showNotification;

// ===============================
// SHORTCUTS
// ===============================
function t(k) { return window.IPTrip ? window.IPTrip.t(k) : k; }
function fmt(v) { return window.IPTrip ? window.IPTrip.formatPrice(v) : ("EUR " + Number(v).toFixed(0)); }
function escapeHtml(s) {
    if (s == null) return "";
    return String(s).replace(/[&<>"']/g, function (c) {
        return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c];
    });
}
function apiFetch(path, opts) {
    var lang = (window.IPTrip && window.IPTrip.state && window.IPTrip.state.lang) || "pt";
    var sep = path.indexOf("?") >= 0 ? "&" : "?";
    return fetch(API + path + sep + "lang=" + lang, opts);
}
var __TYPE_MAP = {
    praia: "opt_beach", cultural: "opt_cultural", romantico: "opt_romantic",
    aventura: "opt_adventure", luxo: "opt_luxury", urbano: "opt_urban",
    gastronomia: "opt_gastronomy", familia: "opt_family", compras: "opt_shopping"
};
var __CONT_MAP = {
    "Europa": "cont_europa", "Asia": "cont_asia", "Ásia": "cont_asia",
    "America": "cont_america", "América": "cont_america",
    "America do Norte": "cont_america_norte", "América do Norte": "cont_america_norte",
    "America do Sul": "cont_america_sul", "América do Sul": "cont_america_sul",
    "Africa": "cont_africa", "África": "cont_africa", "Oceania": "cont_oceania"
};
function localizeType(s) {
    if (!s) return "";
    var key = __TYPE_MAP[s.trim().toLowerCase()];
    return key ? t(key) : s;
}
function localizeContinent(s) {
    if (!s) return "";
    var key = __CONT_MAP[s.trim()];
    return key ? t(key) : s;
}
window.t = t; window.fmt = fmt; window.escapeHtml = escapeHtml; window.apiFetch = apiFetch;
window.localizeType = localizeType; window.localizeContinent = localizeContinent;

// ===============================
// NAV / INIT
// ===============================
document.addEventListener("DOMContentLoaded", function () {
    var header = document.getElementById("header");
    var hamburger = document.getElementById("hamburger");
    var navMenu = document.getElementById("navMenu");

    window.addEventListener("scroll", function () {
        if (window.scrollY > 80) header.classList.add("scrolled"); else header.classList.remove("scrolled");
    });

    if (hamburger) {
        hamburger.addEventListener("click", function () {
            hamburger.classList.toggle("active");
            navMenu.classList.toggle("active");
        });
    }

    updateNavState();
    if (document.getElementById("homeDestinations")) loadHomeDestinations();
    if (document.getElementById("homePackages")) loadHomePackages();
    updateWishlistCount();
    setupAISearch();
});

document.addEventListener("iptrip:settings", function (e) {
    var detail = e && e.detail ? e.detail : {};
    if (detail.langChanged) {
        // Catalog content is localised server-side – re-fetch.
        if (document.getElementById("homeDestinations")) loadHomeDestinations();
        if (document.getElementById("homePackages")) loadHomePackages();
        if (window.refreshActivePage) window.refreshActivePage(true);
    } else {
        // Only currency changed – re-render with cached data.
        if (document.getElementById("homeDestinations") && window.__homeDestinos) renderHomeDestinations(window.__homeDestinos);
        if (document.getElementById("homePackages") && window.__homePacotes) renderHomePackages(window.__homePacotes);
        if (window.refreshActivePage) window.refreshActivePage(false);
    }
});

// ===============================
// NAV STATE
// ===============================
function updateNavState() {
    var userId = localStorage.getItem("user_id");
    var userName = localStorage.getItem("user_name");
    var isAdmin = localStorage.getItem("is_admin") === "1";
    var label = document.getElementById("clientNavLabel");
    var btn = document.getElementById("clientNavBtn");
    if (userId && label && btn) {
        if (isAdmin) {
            label.textContent = "Admin";
            label.removeAttribute("data-i18n");
            btn.href = "admin.html";
            btn.classList.add("nav-btn-admin");
        } else {
            label.textContent = userName || t("nav_dashboard");
            label.setAttribute("data-i18n", "nav_dashboard");
            btn.href = "dashboard.html";
        }
    }
}

function updateWishlistCount() {
    var userId = localStorage.getItem("user_id");
    var badge = document.getElementById("wishlistCount");
    if (!userId || !badge) return;
    fetch(API + "/dreams/" + userId).then(function (r) { return r.json(); }).then(function (data) {
        if (data.length > 0) { badge.textContent = data.length; badge.style.display = "flex"; }
        else { badge.style.display = "none"; }
    }).catch(function () { });
}

// ===============================
// HOME
// ===============================
function loadHomeDestinations() {
    apiFetch("/destinos").then(function (r) { return r.json(); }).then(function (destinos) {
        window.__homeDestinos = destinos.slice(0, 6);
        renderHomeDestinations(window.__homeDestinos);
    }).catch(function () { });
}

function renderHomeDestinations(destinos) {
    var grid = document.getElementById("homeDestinations");
    grid.innerHTML = destinos.map(destinationCard).join("");
}

function destinationCard(d) {
    var types = (d.tipo || "").split(",").filter(Boolean).map(function (x) {
        return '<span class="dest-tag">' + escapeHtml(localizeType(x.trim())) + '</span>';
    }).join("");
    return '<div class="destination-card" data-testid="destination-card-' + d.destination_id + '">' +
        '<div class="dest-image">' +
            '<img src="' + encodeURI(d.imagem_url || "") + '" alt="' + escapeHtml(d.nome) + '" loading="lazy">' +
            '<div class="dest-overlay">' +
                '<button class="btn-wishlist" data-testid="wishlist-btn-' + d.destination_id + '" onclick="toggleWishlist(' + d.destination_id + ', this, event)">' +
                    '<i class="far fa-heart"></i></button></div></div>' +
        '<div class="dest-content">' +
            '<div class="dest-header"><h3>' + escapeHtml(d.nome) + '</h3>' +
                '<span class="dest-country"><i class="fas fa-map-marker-alt"></i> ' + escapeHtml(d.pais) + '</span></div>' +
            '<p class="dest-description">' + escapeHtml((d.descricao || "").substring(0, 100)) + '...</p>' +
            '<div class="dest-tags">' + types + '</div>' +
            '<div class="dest-footer">' +
                '<div class="dest-price"><span class="price-label">' + t("label_from") + '</span>' +
                    '<span class="price-value">' + fmt(d.preco_medio) + '</span></div>' +
                '<button class="btn btn-sm btn-primary" data-testid="buy-dest-' + d.destination_id + '" onclick="buyDestination(' + d.destination_id + ')">' +
                    '<i class="fas fa-shopping-cart"></i> ' + t("btn_buy_now") + '</button>' +
            '</div></div></div>';
}

function loadHomePackages() {
    apiFetch("/pacotes").then(function (r) { return r.json(); }).then(function (pacotes) {
        window.__homePacotes = pacotes.slice(0, 4);
        renderHomePackages(window.__homePacotes);
    }).catch(function () { });
}

function renderHomePackages(pacotes) {
    var grid = document.getElementById("homePackages");
    grid.innerHTML = pacotes.map(packageCard).join("");
}

function packageCard(p) {
    var items = (p.itens_incluidos || []).slice(0, 3).map(function (i) {
        return '<li><i class="fas fa-check"></i> ' + escapeHtml(i) + '</li>';
    }).join("");
    return '<div class="package-card" data-testid="package-card-' + p.package_id + '">' +
        '<div class="pkg-image">' +
            '<img src="' + encodeURI(p.imagem_url || "") + '" alt="' + escapeHtml(p.nome) + '" loading="lazy">' +
            '<span class="pkg-duration"><i class="fas fa-clock"></i> ' + p.duracao + ' ' + t("label_nights") + '</span>' +
            '<span class="pkg-category">' + escapeHtml(p.categoria || "") + '</span></div>' +
        '<div class="pkg-content"><h3>' + escapeHtml(p.nome) + '</h3>' +
            '<p>' + escapeHtml((p.descricao || "").substring(0, 120)) + '...</p>' +
            '<ul class="pkg-items">' + items + '</ul>' +
            '<div class="pkg-footer">' +
                '<div class="pkg-price"><span class="price-label">' + t("label_from") + '</span>' +
                    '<span class="price-value">' + fmt(p.preco) + '</span></div>' +
                '<button class="btn btn-sm btn-primary" data-testid="buy-pkg-' + p.package_id + '" onclick="buyPackage(' + p.package_id + ')">' +
                    '<i class="fas fa-shopping-cart"></i> ' + t("btn_buy_now") + '</button>' +
            '</div></div></div>';
}

// ===============================
// BUY ACTIONS -> Checkout
// ===============================
function buyPackage(id) { window.location.href = "checkout.html?type=package&id=" + id; }
function buyDestination(id) { window.location.href = "checkout.html?type=destination&id=" + id; }
window.buyPackage = buyPackage; window.buyDestination = buyDestination;

// ===============================
// WISHLIST TOGGLE
// ===============================
function toggleWishlist(destinationId, btn, event) {
    if (event) event.stopPropagation();
    var userId = localStorage.getItem("user_id");
    if (!userId) {
        showNotification(t("nav_login"), "info");
        setTimeout(function () { window.location.href = "cliente.html"; }, 1200);
        return;
    }
    var icon = btn.querySelector("i");
    var isActive = icon.classList.contains("fas");
    if (isActive) {
        fetch(API + "/dreams/check/" + userId + "/" + destinationId).then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.dream_id) return fetch(API + "/dreams/delete/" + data.dream_id, { method: "DELETE" });
            })
            .then(function () {
                icon.classList.remove("fas"); icon.classList.add("far");
                btn.classList.remove("active"); updateWishlistCount();
            });
    } else {
        fetch(API + "/dreams/add", { method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ user_id: parseInt(userId), destination_id: destinationId })
        }).then(function (r) { return r.json(); }).then(function (data) {
            if (data.status === "ok") {
                icon.classList.remove("far"); icon.classList.add("fas");
                btn.classList.add("active"); updateWishlistCount();
            }
        });
    }
}
window.toggleWishlist = toggleWishlist;

// ===============================
// AI SEARCH
// ===============================
function setupAISearch() {
    var btn = document.getElementById("aiSearchBtn");
    if (!btn) return;
    var input = document.getElementById("aiSearchInput");
    var results = document.getElementById("aiSearchResults");

    function run() {
        var q = (input.value || "").trim();
        if (!q) return;
        btn.disabled = true;
        results.innerHTML = '<div class="ai-loading"><i class="fas fa-spinner fa-spin"></i> ' + t("ai_searching") + '</div>';
        fetch(API + "/ai-search", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ query: q, lang: window.IPTrip.state.lang })
        }).then(function (r) { return r.json(); }).then(function (data) {
            btn.disabled = false;
            if (data.status !== "ok") {
                results.innerHTML = '<p class="ai-error">' + escapeHtml(data.message || "") + '</p>';
                return;
            }
            renderAISearch(data, results);
        }).catch(function () { btn.disabled = false; results.innerHTML = '<p class="ai-error">Error</p>'; });
    }
    btn.addEventListener("click", run);
    input.addEventListener("keydown", function (e) { if (e.key === "Enter") run(); });
}

function renderAISearch(data, container) {
    var nothing = (!data.destinations || !data.destinations.length) && (!data.packages || !data.packages.length);
    if (nothing) { container.innerHTML = '<p class="ai-empty">' + t("ai_no_results") + '</p>'; return; }

    var html = '';
    if (data.explanation) html += '<p class="ai-explain"><i class="fas fa-magic"></i> ' + escapeHtml(data.explanation) + '</p>';
    html += '<h3 class="ai-results-title">' + t("ai_results_title") + '</h3>';

    if (data.packages && data.packages.length) {
        html += '<div class="ai-grid">';
        html += data.packages.map(packageCard).join("");
        html += '</div>';
    }
    if (data.destinations && data.destinations.length) {
        html += '<div class="ai-grid">';
        html += data.destinations.map(destinationCard).join("");
        html += '</div>';
    }
    container.innerHTML = html;
}
