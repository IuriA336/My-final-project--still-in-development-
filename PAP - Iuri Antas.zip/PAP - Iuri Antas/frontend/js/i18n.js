// ===================================
// IPTrip - i18n + Currency Manager
// ===================================
// Centralised state for language and currency. Re-rendered components
// listen to the `iptrip:settings` event.
// ===================================

(function (global) {
    var STORAGE_LANG = "iptrip_lang";
    var STORAGE_CURRENCY = "iptrip_currency";

    var DEFAULT_LANG = "pt";
    var DEFAULT_CURRENCY = "EUR";

    var FALLBACK_RATES = { EUR: 1, USD: 1.08, GBP: 0.86, ARS: 1100 };
    var SYMBOLS = { EUR: "€", USD: "$", GBP: "£", ARS: "$" };

    var state = {
        lang: localStorage.getItem(STORAGE_LANG) || DEFAULT_LANG,
        currency: localStorage.getItem(STORAGE_CURRENCY) || DEFAULT_CURRENCY,
        rates: FALLBACK_RATES,
        symbols: SYMBOLS
    };

    var T = (typeof window !== "undefined" && window.IPTrip_TRANSLATIONS) || {};

    function t(key) {
        var dict = T[state.lang] || T[DEFAULT_LANG] || {};
        if (dict[key] !== undefined) return dict[key];
        var fb = T[DEFAULT_LANG] || {};
        return fb[key] !== undefined ? fb[key] : key;
    }

    function formatPrice(amountEur) {
        if (amountEur === null || amountEur === undefined || isNaN(amountEur)) return "";
        var rate = state.rates[state.currency] || 1;
        var converted = Number(amountEur) * rate;
        var symbol = state.symbols[state.currency] || "€";
        var code = state.currency;
        var rounded;
        if (state.currency === "ARS") {
            rounded = Math.round(converted).toLocaleString("es-AR");
        } else {
            rounded = converted.toLocaleString(state.lang === "pt" ? "pt-PT"
                                              : state.lang === "es" ? "es-ES"
                                              : state.lang === "fr" ? "fr-FR" : "en-US",
                                              { maximumFractionDigits: 0 });
        }
        return symbol + " " + rounded + " " + code;
    }

    function applyDomTranslations(root) {
        var scope = root || document;
        var nodes = scope.querySelectorAll("[data-i18n]");
        nodes.forEach(function (el) {
            var key = el.getAttribute("data-i18n");
            var val = t(key);
            if (el.hasAttribute("data-i18n-html")) el.innerHTML = val;
            else el.textContent = val;
        });
        var attrNodes = scope.querySelectorAll("[data-i18n-placeholder]");
        attrNodes.forEach(function (el) {
            el.setAttribute("placeholder", t(el.getAttribute("data-i18n-placeholder")));
        });
        var titleNodes = scope.querySelectorAll("[data-i18n-title]");
        titleNodes.forEach(function (el) {
            el.setAttribute("title", t(el.getAttribute("data-i18n-title")));
        });
        document.documentElement.setAttribute("lang", state.lang);
    }

    function fireSettingsChanged(opts) {
        document.dispatchEvent(new CustomEvent("iptrip:settings", {
            detail: Object.assign({ lang: state.lang, currency: state.currency }, opts || {})
        }));
    }

    function setLang(lang) {
        state.lang = lang;
        localStorage.setItem(STORAGE_LANG, lang);
        applyDomTranslations();
        fireSettingsChanged({ langChanged: true });
    }

    function setCurrency(currency) {
        state.currency = currency;
        localStorage.setItem(STORAGE_CURRENCY, currency);
        fireSettingsChanged({ currencyChanged: true });
    }

    function fetchRates() {
        var apiBase = window.location.origin + "/api";
        return fetch(apiBase + "/exchange-rates")
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data && data.rates) {
                    state.rates = Object.assign({}, FALLBACK_RATES, data.rates);
                    state.rates.EUR = 1;
                    if (data.symbols) state.symbols = Object.assign({}, SYMBOLS, data.symbols);
                }
                fireSettingsChanged();
            })
            .catch(function () { /* fallback already in place */ });
    }

    function injectControls() {
        var navActions = document.querySelector(".nav-actions");
        if (!navActions || document.getElementById("langSelect")) return;

        var wrapper = document.createElement("div");
        wrapper.className = "locale-controls";
        wrapper.innerHTML =
            '<select id="langSelect" class="locale-select" data-testid="language-select" aria-label="Language">' +
                '<option value="pt">PT</option>' +
                '<option value="en">EN</option>' +
                '<option value="es">ES</option>' +
                '<option value="fr">FR</option>' +
            '</select>' +
            '<select id="currencySelect" class="locale-select" data-testid="currency-select" aria-label="Currency">' +
                '<option value="EUR">EUR €</option>' +
                '<option value="USD">USD $</option>' +
                '<option value="GBP">GBP £</option>' +
                '<option value="ARS">ARS $</option>' +
            '</select>';

        navActions.insertBefore(wrapper, navActions.firstChild);

        var langSel = wrapper.querySelector("#langSelect");
        var curSel = wrapper.querySelector("#currencySelect");
        langSel.value = state.lang;
        curSel.value = state.currency;
        langSel.addEventListener("change", function () { setLang(this.value); });
        curSel.addEventListener("change", function () { setCurrency(this.value); });
    }

    var api = {
        get state() { return state; },
        t: t,
        formatPrice: formatPrice,
        setLang: setLang,
        setCurrency: setCurrency,
        applyDomTranslations: applyDomTranslations
    };

    global.IPTrip = api;

    document.addEventListener("DOMContentLoaded", function () {
        injectControls();
        applyDomTranslations();
        fetchRates();
    });
})(window);
