// ===================================
// Pacotes Page JavaScript
// ===================================
var allPackages = [];
var currentCategory = "all";

document.addEventListener("DOMContentLoaded", function () {
    loadPackages();
    setupCategoryTabs();
});

window.refreshActivePage = function (langChanged) {
    if (langChanged) loadPackages();
    else renderActive();
};

function loadPackages() {
    apiFetch("/pacotes").then(function (r) { return r.json(); }).then(function (p) {
        allPackages = p; renderActive();
    }).catch(function () { showNotification("Erro", "error"); });
}

function renderActive() {
    var list = currentCategory === "all" ? allPackages : allPackages.filter(function (p) { return p.categoria === currentCategory; });
    renderPackages(list);
}

function renderPackages(pacotes) {
    var grid = document.getElementById("packagesGrid");
    if (!grid) return;
    grid.innerHTML = pacotes.map(function (p) {
        var items = (p.itens_incluidos || []).map(function (i) {
            return '<li><i class="fas fa-check"></i> ' + escapeHtml(i) + '</li>';
        }).join("");
        return '<div class="package-card-full" data-testid="package-card-' + p.package_id + '" data-category="' + escapeHtml(p.categoria || "") + '">' +
            '<div class="pkg-image-full">' +
                '<img src="' + encodeURI(p.imagem_url || "") + '" alt="' + escapeHtml(p.nome) + '" loading="lazy">' +
                '<div class="pkg-badges">' +
                    '<span class="pkg-duration"><i class="fas fa-clock"></i> ' + p.duracao + ' ' + t("label_nights") + '</span>' +
                    '<span class="pkg-category-badge">' + escapeHtml(p.categoria || "") + '</span></div></div>' +
            '<div class="pkg-content-full"><h3>' + escapeHtml(p.nome) + '</h3>' +
                '<p class="pkg-destination"><i class="fas fa-map-marker-alt"></i> ' + escapeHtml(p.destino_principal || "") + '</p>' +
                '<p class="pkg-desc">' + escapeHtml(p.descricao || "") + '</p>' +
                '<ul class="pkg-items-full">' + items + '</ul>' +
                '<div class="pkg-footer-full">' +
                    '<div class="pkg-price-full"><span class="price-label">' + t("label_from") + '</span>' +
                        '<span class="price-value">' + fmt(p.preco) + '</span>' +
                        '<span class="price-person">' + t("label_per_person") + '</span></div>' +
                    '<button class="btn btn-primary" data-testid="buy-pkg-full-' + p.package_id + '" onclick="buyPackage(' + p.package_id + ')">' +
                        '<i class="fas fa-shopping-cart"></i> ' + t("btn_buy_now") + '</button>' +
                '</div></div></div>';
    }).join("");
}

function setupCategoryTabs() {
    var tabs = document.querySelectorAll(".category-tab");
    tabs.forEach(function (tab) {
        tab.addEventListener("click", function () {
            currentCategory = tab.dataset.category;
            tabs.forEach(function (t) { t.classList.remove("active"); });
            tab.classList.add("active");
            renderActive();
        });
    });
}
