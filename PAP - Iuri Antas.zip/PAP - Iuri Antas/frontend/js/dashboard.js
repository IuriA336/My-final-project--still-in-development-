// ===================================
// Dashboard Page JavaScript
// ===================================

document.addEventListener("DOMContentLoaded", function() {
    var userId = localStorage.getItem("user_id");

    if (!userId) {
        window.location.href = "cliente.html";
        return;
    }

    initDashboard(userId);
});

function initDashboard(userId) {
    loadUserData(userId);
    loadWishlist(userId);
    loadBookings(userId);
    setupDashboardNav();
}

// ===============================
// LOAD USER DATA
// ===============================
function loadUserData(userId) {
    fetch(API + "/user/" + userId)
        .then(function(r) { return r.json(); })
        .then(function(user) {
            document.querySelectorAll(".client-name").forEach(function(el) {
                el.textContent = user.nome;
            });
            document.querySelectorAll(".client-email").forEach(function(el) {
                el.textContent = user.email;
            });

            var phone = document.getElementById("clientPhone");
            if (phone) phone.textContent = user.telefone || "-";

            var since = document.getElementById("clientSince");
            if (since && user.data_criacao) {
                since.textContent = new Date(user.data_criacao).toLocaleDateString("pt-PT");
            }
        })
        .catch(function(err) {
            
            showNotification("Erro ao carregar dados do utilizador.", "error");
        });
}

// ===============================
// LOAD WISHLIST (from database)
// ===============================
function loadWishlist(userId) {
    fetch(API + "/dreams/" + userId)
        .then(function(r) { return r.json(); })
        .then(function(dreams) {
            // Update stat
            var statEl = document.getElementById("statDreams");
            if (statEl) statEl.textContent = dreams.length;

            // Render preview (overview panel)
            renderWishlistPreview(dreams);

            // Render full wishlist panel
            renderWishlistFull(dreams);
        })
        .catch(function(err) {
            
        });
}

function renderWishlistPreview(dreams) {
    var container = document.getElementById("wishlistPreview");
    if (!container) return;

    if (dreams.length === 0) {
        container.innerHTML = '<p class="empty-state"><i class="fas fa-heart-broken"></i> Ainda nao adicionou destinos a sua lista de desejos. <a href="destinos.html">Explorar destinos</a></p>';
        return;
    }

    var preview = dreams.slice(0, 3);
    container.innerHTML = '<div class="wishlist-preview-grid">' +
        preview.map(function(d) {
            return '<div class="wishlist-preview-card">' +
                '<img src="' + (d.imagem_url || "") + '" alt="' + d.nome + '">' +
                '<div class="wpc-info">' +
                    '<strong>' + d.nome + '</strong>' +
                    '<span>' + d.pais + '</span>' +
                '</div>' +
            '</div>';
        }).join("") +
    '</div>' +
    (dreams.length > 3 ? '<a href="#" class="view-all-link" onclick="document.querySelector(\'[data-section=wishlist]\').click(); return false;">Ver todos (' + dreams.length + ')</a>' : '');
}

function renderWishlistFull(dreams) {
    var container = document.getElementById("wishlistFull");
    if (!container) return;

    if (dreams.length === 0) {
        container.innerHTML = '<div class="empty-state-full">' +
            '<i class="fas fa-heart-broken"></i>' +
            '<h3>A sua lista de desejos esta vazia</h3>' +
            '<p>Explore os nossos destinos e adicione os seus favoritos!</p>' +
            '<a href="destinos.html" class="btn btn-primary">Explorar Destinos</a>' +
        '</div>';
        return;
    }

    container.innerHTML = '<div class="wishlist-grid">' +
        dreams.map(function(d) {
            var types = (d.tipo || "").split(",").map(function(t) {
                return '<span class="dest-tag">' + t.trim() + '</span>';
            }).join("");

            return '<div class="wishlist-card">' +
                '<div class="wc-image">' +
                    '<img src="' + (d.imagem_url || "") + '" alt="' + d.nome + '">' +
                '</div>' +
                '<div class="wc-content">' +
                    '<h4>' + d.nome + '</h4>' +
                    '<p class="wc-country"><i class="fas fa-map-marker-alt"></i> ' + d.pais + ', ' + d.continente + '</p>' +
                    '<p class="wc-desc">' + (d.descricao || "").substring(0, 100) + '...</p>' +
                    '<div class="wc-tags">' + types + '</div>' +
                    '<div class="wc-footer">' +
                        '<span class="wc-price">EUR ' + Number(d.preco_medio).toFixed(0) + '</span>' +
                        '<span class="wc-date">Adicionado: ' + new Date(d.data_adicionado).toLocaleDateString("pt-PT") + '</span>' +
                        '<button class="btn btn-danger btn-sm" onclick="removeDream(' + d.dream_id + ')"><i class="fas fa-trash"></i> Remover</button>' +
                    '</div>' +
                '</div>' +
            '</div>';
        }).join("") +
    '</div>';
}

// ===============================
// REMOVE FROM WISHLIST
// ===============================
function removeDream(dreamId) {
    fetch(API + "/dreams/delete/" + dreamId, { method: "DELETE" })
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.status === "ok") {
                showNotification("Destino removido da lista de desejos!", "info");
                var userId = localStorage.getItem("user_id");
                loadWishlist(userId);
                updateWishlistCount();
            }
        })
        .catch(function() {
            showNotification("Erro ao remover.", "error");
        });
}

window.removeDream = removeDream;

// ===============================
// LOAD BOOKINGS
// ===============================
function loadBookings(userId) {
    fetch(API + "/reservas/" + userId)
        .then(function(r) { return r.json(); })
        .then(function(reservas) {
            var statEl = document.getElementById("statBookings");
            if (statEl) statEl.textContent = reservas.length;

            var container = document.getElementById("bookingsList");
            if (!container) return;

            if (reservas.length === 0) {
                container.innerHTML = '<div class="empty-state-full">' +
                    '<i class="fas fa-calendar-times"></i>' +
                    '<h3>Sem reservas ainda</h3>' +
                    '<p>Explore os nossos pacotes e faca a sua primeira reserva!</p>' +
                    '<a href="pacotes.html" class="btn btn-primary">Ver Pacotes</a>' +
                '</div>';
                return;
            }

            container.innerHTML = reservas.map(function(r) {
                var estado = r.estado.charAt(0).toUpperCase() + r.estado.slice(1);
                return '<div class="booking-card">' +
                    '<div class="bc-info">' +
                        '<h4><i class="fas fa-suitcase"></i> ' + (r.nome_destino || "Reserva #" + r.booking_id) + '</h4>' +
                        '<p><i class="fas fa-calendar"></i> ' + new Date(r.data_reserva).toLocaleDateString("pt-PT") + '</p>' +
                        '<p><i class="fas fa-credit-card"></i> Total: EUR ' + Number(r.total).toFixed(2) + '</p>' +
                    '</div>' +
                    '<span class="booking-status status-' + r.estado + '">' + estado + '</span>' +
                '</div>';
            }).join("");
        })
        .catch(function(err) {
            
        });
}

// ===============================
// DASHBOARD NAVIGATION
// ===============================
function setupDashboardNav() {
    var links = document.querySelectorAll(".dashboard-menu a[data-section]");
    var panels = document.querySelectorAll(".dashboard-panel");

    links.forEach(function(link) {
        link.addEventListener("click", function(e) {
            e.preventDefault();

            var section = link.dataset.section;

            if (section === "logout") {
                localStorage.removeItem("user_id");
                localStorage.removeItem("user_name");
                showNotification("Sessao terminada com sucesso!", "info");
                setTimeout(function() { window.location.href = "cliente.html"; }, 1000);
                return;
            }

            links.forEach(function(l) { l.classList.remove("active"); });
            link.classList.add("active");

            panels.forEach(function(panel) {
                if (panel.id === section) {
                    panel.classList.add("active");
                } else {
                    panel.classList.remove("active");
                }
            });
        });
    });
}