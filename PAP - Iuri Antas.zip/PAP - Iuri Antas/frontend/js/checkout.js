// ===================================
// Checkout Page
// ===================================
var currentItem = null;
var itemType = null;

document.addEventListener("DOMContentLoaded", function () {
    var params = new URLSearchParams(window.location.search);
    itemType = params.get("type");
    var id = parseInt(params.get("id"));
    if (!itemType || !id) { window.location.href = "index.html"; return; }

    var endpoint = itemType === "package" ? "/pacotes/" + id : "/destinos/" + id;
    apiFetch(endpoint).then(function (r) { return r.json(); }).then(function (data) {
        currentItem = data;
        renderCheckout();
    });
});

document.addEventListener("iptrip:settings", function (e) {
    if (!currentItem) return;
    if (e && e.detail && e.detail.langChanged) {
        // re-fetch translated copy
        var endpoint = itemType === "package" ? "/pacotes/" + currentItem.package_id : "/destinos/" + currentItem.destination_id;
        apiFetch(endpoint).then(function (r) { return r.json(); }).then(function (data) {
            currentItem = data;
            renderCheckout();
        });
    } else {
        renderCheckout();
    }
});

function renderCheckout() {
    var item = currentItem;
    var price = itemType === "package" ? item.preco : item.preco_medio;
    var name = item.nome + (itemType === "destination" ? ", " + item.pais : "");
    var image = item.imagem_url;
    var info = itemType === "package" ?
        ('<i class="fas fa-map-marker-alt"></i> ' + escapeHtml(item.destino_principal || "") + ' · <i class="fas fa-clock"></i> ' + item.duracao + ' ' + t("label_nights"))
        : ('<i class="fas fa-globe"></i> ' + escapeHtml(item.continente || ""));

    var userName = localStorage.getItem("user_name") || "";

    var html =
    '<div class="checkout-layout">' +
        '<div class="checkout-card">' +
            '<h2><i class="fas fa-credit-card"></i> ' + t("checkout_title") + '</h2>' +
            '<form id="checkoutForm" autocomplete="on">' +
                '<div class="checkout-block">' +
                    '<h4>' + t("checkout_traveler") + '</h4>' +
                    '<div class="form-row">' +
                        '<div class="form-group"><label>' + t("label_name") + '</label>' +
                            '<input type="text" id="ck_nome" data-testid="checkout-name" value="' + escapeHtml(userName) + '" required></div>' +
                        '<div class="form-group"><label>' + t("label_email") + '</label>' +
                            '<input type="email" id="ck_email" data-testid="checkout-email" required></div>' +
                    '</div>' +
                    '<div class="form-row">' +
                        '<div class="form-group"><label>' + t("label_phone") + '</label>' +
                            '<input type="tel" id="ck_telefone" data-testid="checkout-phone"></div>' +
                        '<div class="form-group"><label>' + t("label_travelers") + '</label>' +
                            '<input type="number" id="ck_travelers" data-testid="checkout-travelers" min="1" value="1" required></div>' +
                    '</div>' +
                    '<div class="form-group"><label>' + t("label_travel_date") + '</label>' +
                        '<input type="date" id="ck_date" data-testid="checkout-date" required></div>' +
                '</div>' +
                '<div class="checkout-block">' +
                    '<h4>' + t("checkout_payment") + '</h4>' +
                    '<div class="form-group"><label>' + t("label_card_number") + '</label>' +
                        '<input type="text" id="ck_card" data-testid="checkout-card-number" placeholder="4242 4242 4242 4242" required maxlength="23"></div>' +
                    '<div class="form-group"><label>' + t("label_card_name") + '</label>' +
                        '<input type="text" id="ck_card_name" data-testid="checkout-card-name" required></div>' +
                    '<div class="form-row">' +
                        '<div class="form-group"><label>' + t("label_card_expiry") + '</label>' +
                            '<input type="text" id="ck_expiry" data-testid="checkout-card-expiry" placeholder="12/28" required maxlength="5"></div>' +
                        '<div class="form-group"><label>' + t("label_card_cvc") + '</label>' +
                            '<input type="text" id="ck_cvc" data-testid="checkout-card-cvc" placeholder="123" required maxlength="4"></div>' +
                    '</div>' +
                '</div>' +
                '<button type="submit" class="btn btn-primary btn-block btn-lg" data-testid="checkout-pay-btn">' +
                    '<i class="fas fa-lock"></i> ' + t("btn_pay") + ' <span id="ck_total_btn">' + fmt(price) + '</span></button>' +
            '</form>' +
        '</div>' +
        '<aside class="checkout-summary">' +
            '<h3><i class="fas fa-receipt"></i> ' + t("checkout_summary") + '</h3>' +
            '<div class="summary-trip">' +
                '<img src="' + encodeURI(image || "") + '" alt="' + escapeHtml(name) + '">' +
                '<div><h4>' + escapeHtml(name) + '</h4><p>' + info + '</p></div></div>' +
            '<div class="summary-row"><span>' + t("label_from") + '</span><span>' + fmt(price) + ' ' + t("label_per_person") + '</span></div>' +
            '<div class="summary-row"><span>' + t("label_travelers") + '</span><span id="sm_travelers">1</span></div>' +
            '<div class="summary-total"><span>' + t("checkout_total") + '</span><span id="sm_total">' + fmt(price) + '</span></div>' +
        '</aside>' +
    '</div>';
    document.getElementById("checkoutContent").innerHTML = html;

    var travelersInput = document.getElementById("ck_travelers");
    travelersInput.addEventListener("input", updateTotal);

    // card formatting
    var cardInput = document.getElementById("ck_card");
    cardInput.addEventListener("input", function () {
        var v = this.value.replace(/\D/g, "").substring(0, 19);
        var parts = [];
        for (var i = 0; i < v.length; i += 4) parts.push(v.substring(i, i + 4));
        this.value = parts.join(" ");
    });
    var expInput = document.getElementById("ck_expiry");
    expInput.addEventListener("input", function () {
        var v = this.value.replace(/\D/g, "").substring(0, 4);
        if (v.length >= 3) this.value = v.substring(0, 2) + "/" + v.substring(2);
        else this.value = v;
    });
    var cvcInput = document.getElementById("ck_cvc");
    cvcInput.addEventListener("input", function () { this.value = this.value.replace(/\D/g, "").substring(0, 4); });

    document.getElementById("checkoutForm").addEventListener("submit", submitCheckout);
    updateTotal();
}

function updateTotal() {
    if (!currentItem) return;
    var price = itemType === "package" ? currentItem.preco : currentItem.preco_medio;
    var n = parseInt(document.getElementById("ck_travelers").value) || 1;
    var total = price * n;
    document.getElementById("sm_travelers").textContent = n;
    document.getElementById("sm_total").textContent = fmt(total);
    document.getElementById("ck_total_btn").textContent = fmt(total);
}

function submitCheckout(e) {
    e.preventDefault();
    var price = itemType === "package" ? currentItem.preco : currentItem.preco_medio;
    var travelers = parseInt(document.getElementById("ck_travelers").value) || 1;

    var payload = {
        nome: document.getElementById("ck_nome").value.trim(),
        email: document.getElementById("ck_email").value.trim(),
        telefone: document.getElementById("ck_telefone").value.trim(),
        card_number: document.getElementById("ck_card").value.replace(/\s+/g, ""),
        card_name: document.getElementById("ck_card_name").value.trim(),
        card_expiry: document.getElementById("ck_expiry").value.trim(),
        card_cvc: document.getElementById("ck_cvc").value.trim(),
        travelers: travelers,
        travel_date: document.getElementById("ck_date").value,
        total_eur: price,
        user_id: localStorage.getItem("user_id") ? parseInt(localStorage.getItem("user_id")) : null
    };
    if (itemType === "package") payload.package_id = currentItem.package_id;
    else payload.destination_id = currentItem.destination_id;

    var btn = document.querySelector("#checkoutForm button[type='submit']");
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + t("processing");

    fetch(API + "/checkout", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) })
        .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, body: d }; }); })
        .then(function (res) {
            if (!res.ok || res.body.status !== "ok") {
                showNotification(t("err_payment") + " " + (res.body.message || ""), "error");
                btn.disabled = false; btn.innerHTML = '<i class="fas fa-lock"></i> ' + t("btn_pay");
                return;
            }
            renderSuccess(res.body);
        }).catch(function () {
            showNotification(t("err_payment"), "error");
            btn.disabled = false; btn.innerHTML = '<i class="fas fa-lock"></i> ' + t("btn_pay");
        });
}

function renderSuccess(data) {
    var html = '<div class="success-card" data-testid="checkout-success">' +
        '<div class="check"><i class="fas fa-check"></i></div>' +
        '<h2>' + t("checkout_success_title") + '</h2>' +
        '<p>' + t("checkout_success_msg") + '</p>' +
        '<div class="confirmation-code"><strong>' + t("checkout_confirmation") + ':</strong> ' + escapeHtml(data.confirmation) + '</div>' +
        '<p>' + t("checkout_total") + ': <strong>' + fmt(data.total_eur) + '</strong> · Card ****' + escapeHtml(data.card_last4) + '</p>' +
        '<a href="index.html" class="btn btn-primary"><i class="fas fa-home"></i> ' + t("btn_back_home") + '</a>' +
    '</div>';
    document.getElementById("checkoutContent").innerHTML = html;
}
