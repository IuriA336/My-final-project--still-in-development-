// ===================================
// Destinos Page JavaScript
// ===================================
var allDestinations = [];

document.addEventListener("DOMContentLoaded", function () {
    loadDestinations();
    setupFilters();
});

window.refreshActivePage = function (langChanged) {
    if (langChanged) loadDestinations();
    else applyFilters();
};

function loadDestinations() {
    apiFetch("/destinos").then(function (r) { return r.json(); }).then(function (d) {
        allDestinations = d; renderDestinations(d); checkWishlistState(d);
    });
}

function renderDestinations(destinos) {
    var grid = document.getElementById("destinationsGrid");
    var noResults = document.getElementById("noResults");
    if (destinos.length === 0) { grid.innerHTML = ""; noResults.style.display = "block"; return; }
    noResults.style.display = "none";
    grid.innerHTML = destinos.map(function (d) {
        var types = (d.tipo || "").split(",").filter(Boolean).map(function (x) {
            return '<span class="dest-tag">' + escapeHtml(localizeType(x.trim())) + '</span>';
        }).join("");
        var destaques = (d.destaques || []).map(function (h) {
            return '<li><i class="fas fa-check-circle"></i> ' + escapeHtml(h) + '</li>';
        }).join("");
        return '<div class="destination-card-full" data-testid="destination-card-' + d.destination_id + '" data-id="' + d.destination_id + '">' +
            '<div class="dest-image-full">' +
                '<img src="' + encodeURI(d.imagem_url || "") + '" alt="' + escapeHtml(d.nome) + '" loading="lazy">' +
                '<button class="btn-wishlist" id="wish-' + d.destination_id + '" data-testid="wishlist-btn-' + d.destination_id + '" onclick="toggleWishlist(' + d.destination_id + ', this, event)">' +
                    '<i class="far fa-heart"></i></button></div>' +
            '<div class="dest-content-full">' +
                '<div class="dest-header-full">' +
                    '<h3>' + escapeHtml(d.nome) + ', ' + escapeHtml(d.pais) + '</h3>' +
                    '<span class="dest-continent"><i class="fas fa-globe"></i> ' + escapeHtml(localizeContinent(d.continente)) + '</span></div>' +
                '<p class="dest-desc-full">' + escapeHtml(d.descricao || "") + '</p>' +
                '<div class="dest-tags">' + types + '</div>' +
                '<ul class="dest-highlights">' + destaques + '</ul>' +
                '<div class="dest-footer-full">' +
                    '<div class="dest-price-full"><span class="price-label">' + t("label_from") + '</span>' +
                        '<span class="price-value">' + fmt(d.preco_medio) + '</span></div>' +
                    '<div class="dest-actions">' +
                        '<button class="btn btn-outline-primary btn-sm" onclick="toggleWishlist(' + d.destination_id + ', document.getElementById(\'wish-' + d.destination_id + '\'), event)"><i class="fas fa-heart"></i> ' + t("btn_add_wishlist") + '</button>' +
                        '<button class="btn btn-primary btn-sm" data-testid="buy-dest-full-' + d.destination_id + '" onclick="buyDestination(' + d.destination_id + ')"><i class="fas fa-shopping-cart"></i> ' + t("btn_buy_now") + '</button>' +
                    '</div></div></div></div>';
    }).join("");
}

function checkWishlistState(destinos) {
    var userId = localStorage.getItem("user_id");
    if (!userId) return;
    fetch(API + "/dreams/" + userId).then(function (r) { return r.json(); }).then(function (dreams) {
        var ids = dreams.map(function (d) { return d.destination_id; });
        destinos.forEach(function (d) {
            if (ids.indexOf(d.destination_id) !== -1) {
                var btn = document.getElementById("wish-" + d.destination_id);
                if (btn) { var i = btn.querySelector("i"); i.classList.remove("far"); i.classList.add("fas"); btn.classList.add("active"); }
            }
        });
    });
}

function setupFilters() {
    ["continentFilter", "typeFilter", "budgetFilter", "searchFilter"].forEach(function (id) {
        var el = document.getElementById(id);
        if (el) el.addEventListener("input", applyFilters);
    });
}

function applyFilters() {
    var continent = document.getElementById("continentFilter").value;
    var type = document.getElementById("typeFilter").value;
    var budget = document.getElementById("budgetFilter").value;
    var search = document.getElementById("searchFilter").value.toLowerCase();
    var filtered = allDestinations.filter(function (d) {
        if (continent !== "all" && d.continente !== continent) return false;
        if (type !== "all" && (d.tipo || "").indexOf(type) === -1) return false;
        if (budget !== "all") {
            var p = d.preco_medio;
            if (budget === "low" && p > 1500) return false;
            if (budget === "medium" && (p < 1500 || p > 3000)) return false;
            if (budget === "high" && (p < 3000 || p > 5000)) return false;
            if (budget === "premium" && p < 5000) return false;
        }
        if (search && (d.nome + " " + d.pais + " " + d.descricao).toLowerCase().indexOf(search) === -1) return false;
        return true;
    });
    renderDestinations(filtered);
    checkWishlistState(filtered);
}
