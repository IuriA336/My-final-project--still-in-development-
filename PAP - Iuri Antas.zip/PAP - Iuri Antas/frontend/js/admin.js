// ===================================
// IPTrip - Admin Console JS
// ===================================
var API = window.location.origin + "/api";

document.addEventListener("DOMContentLoaded", function () {
    if (localStorage.getItem("is_admin") !== "1") {
        window.location.href = "cliente.html";
        return;
    }
    document.getElementById("adminUserName").textContent = localStorage.getItem("user_name") || "Admin";

    document.getElementById("adminLogout").addEventListener("click", function () {
        ["user_id", "user_name", "is_admin", "user_role"].forEach(function (k) { localStorage.removeItem(k); });
        window.location.href = "index.html";
    });

    document.querySelectorAll(".admin-nav-item[data-section]").forEach(function (a) {
        a.addEventListener("click", function (e) {
            e.preventDefault();
            switchSection(a.dataset.section);
        });
    });

    document.getElementById("modalClose").addEventListener("click", closeModal);
    document.getElementById("adminModal").addEventListener("click", function (e) {
        if (e.target.id === "adminModal") closeModal();
    });

    document.getElementById("addDestBtn").addEventListener("click", function () { openDestModal(null); });
    document.getElementById("addPkgBtn").addEventListener("click", function () { openPkgModal(null); });

    loadOverview();
});

function authHeaders() {
    return { "Content-Type": "application/json", "X-User-Id": localStorage.getItem("user_id") };
}

function showNotification(msg, type) {
    var box = document.getElementById("notificationContainer");
    var n = document.createElement("div");
    n.className = "notification notification-" + (type || "info");
    n.innerHTML = '<i class="fas fa-' + (type === "success" ? "check-circle" : type === "error" ? "exclamation-circle" : "info-circle") + '"></i><span>' + msg + '</span>';
    box.appendChild(n);
    setTimeout(function () { n.classList.add("show"); }, 10);
    setTimeout(function () { n.classList.remove("show"); setTimeout(function () { n.remove(); }, 300); }, 3500);
}

function fmtEur(v) { return "€ " + Number(v || 0).toLocaleString("pt-PT", { maximumFractionDigits: 0 }); }
function fmtDate(s) {
    if (!s) return "—";
    var d = new Date(s);
    return isNaN(d) ? s : d.toLocaleString("pt-PT", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
}
function esc(s) { return (s == null ? "" : String(s)).replace(/[&<>"']/g, function (c) { return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]); }); }

function switchSection(name) {
    document.querySelectorAll(".admin-nav-item").forEach(function (a) {
        a.classList.toggle("active", a.dataset.section === name);
    });
    document.querySelectorAll(".admin-section").forEach(function (s) {
        s.classList.toggle("active", s.id === "section-" + name);
    });
    if (name === "overview") loadOverview();
    else if (name === "bookings") loadBookings();
    else if (name === "destinations") loadDestinations();
    else if (name === "packages") loadPackages();
    else if (name === "users") loadUsers();
}

// ============ OVERVIEW ============
function loadOverview() {
    fetch(API + "/admin/stats", { headers: authHeaders() })
        .then(function (r) { return r.json(); })
        .then(function (s) {
            document.getElementById("statsGrid").innerHTML =
                statCard("Reservas", s.bookings_total, "fa-receipt", "") +
                statCard("Receita confirmada", fmtEur(s.revenue_eur), "fa-coins", "accent") +
                statCard("Clientes", s.users_total, "fa-users", "success") +
                statCard("Destinos", s.destinations_total, "fa-map-marked-alt", "") +
                statCard("Pacotes", s.packages_total, "fa-box-open", "warn");

            document.getElementById("topDestList").innerHTML = (s.top_destinations || []).map(function (d) {
                return '<li><span></span><span>' + esc(d.nome) + ', ' + esc(d.pais) + '</span><span class="count">' + d.reservas + '</span></li>';
            }).join("") || '<li><span></span><span style="color:#999">Sem reservas ainda</span></li>';
            document.getElementById("topPkgList").innerHTML = (s.top_packages || []).map(function (p) {
                return '<li><span></span><span>' + esc(p.nome) + '</span><span class="count">' + p.reservas + '</span></li>';
            }).join("") || '<li><span></span><span style="color:#999">Sem reservas ainda</span></li>';
        });
}

function statCard(label, value, icon, mod) {
    return '<div class="stat-card ' + (mod || "") + '">' +
        '<div class="label"><i class="fas ' + icon + '"></i> ' + label + '</div>' +
        '<div class="value">' + value + '</div></div>';
}

// ============ BOOKINGS ============
function loadBookings() {
    fetch(API + "/admin/bookings", { headers: authHeaders() })
        .then(function (r) { return r.json(); })
        .then(function (rows) {
            document.getElementById("bookingsTbody").innerHTML = rows.map(function (b) {
                return '<tr data-testid="booking-row-' + b.booking_id + '">' +
                    '<td>#' + b.booking_id + '</td>' +
                    '<td>' + fmtDate(b.data_reserva) + '</td>' +
                    '<td>' + esc(b.cliente) + '</td>' +
                    '<td><a href="mailto:' + esc(b.email) + '">' + esc(b.email) + '</a></td>' +
                    '<td><span class="badge tipo-' + b.tipo + '">' + b.tipo + '</span></td>' +
                    '<td>' + esc(b.item || "") + '</td>' +
                    '<td>' + fmtEur(b.total) + '</td>' +
                    '<td>' +
                        '<select class="status-select" data-id="' + b.booking_id + '" data-testid="status-select-' + b.booking_id + '">' +
                        ["pendente", "confirmada", "cancelada"].map(function (s) {
                            return '<option value="' + s + '"' + (b.estado === s ? " selected" : "") + '>' + s + '</option>';
                        }).join("") + '</select>' +
                    '</td>' +
                    '<td><button class="icon-btn danger" data-del="' + b.booking_id + '" data-testid="del-booking-' + b.booking_id + '"><i class="fas fa-trash"></i></button></td>' +
                    '</tr>';
            }).join("") || '<tr><td colspan="9" style="text-align:center;color:#999">Sem reservas ainda</td></tr>';

            document.querySelectorAll(".status-select").forEach(function (sel) {
                sel.addEventListener("change", function () {
                    fetch(API + "/admin/bookings/" + sel.dataset.id, {
                        method: "PATCH", headers: authHeaders(),
                        body: JSON.stringify({ estado: sel.value })
                    }).then(function (r) { return r.json(); })
                      .then(function () { showNotification("Estado atualizado", "success"); });
                });
            });
            document.querySelectorAll("[data-del]").forEach(function (b) {
                b.addEventListener("click", function () {
                    if (!confirm("Eliminar reserva #" + b.dataset.del + "?")) return;
                    fetch(API + "/admin/bookings/" + b.dataset.del, { method: "DELETE", headers: authHeaders() })
                        .then(function (r) { return r.json(); }).then(function () { showNotification("Reserva eliminada", "success"); loadBookings(); });
                });
            });
        });
}

// ============ DESTINATIONS ============
function loadDestinations() {
    fetch(API + "/destinos?lang=pt").then(function (r) { return r.json(); }).then(function (rows) {
        document.getElementById("destTbody").innerHTML = rows.map(function (d) {
            return '<tr><td>#' + d.destination_id + '</td>' +
                '<td>' + esc(d.nome) + '</td>' +
                '<td>' + esc(d.pais) + '</td>' +
                '<td>' + esc(d.continente || "") + '</td>' +
                '<td>' + esc(d.tipo || "") + '</td>' +
                '<td>' + fmtEur(d.preco_medio) + '</td>' +
                '<td class="row-actions">' +
                    '<button class="icon-btn" data-edit-dest="' + d.destination_id + '" data-testid="edit-dest-' + d.destination_id + '"><i class="fas fa-pen"></i></button>' +
                    '<button class="icon-btn danger" data-del-dest="' + d.destination_id + '" data-testid="del-dest-' + d.destination_id + '"><i class="fas fa-trash"></i></button>' +
                '</td></tr>';
        }).join("");
        document.querySelectorAll("[data-edit-dest]").forEach(function (b) {
            b.addEventListener("click", function () {
                var d = rows.find(function (x) { return x.destination_id === parseInt(b.dataset.editDest, 10); });
                openDestModal(d);
            });
        });
        document.querySelectorAll("[data-del-dest]").forEach(function (b) {
            b.addEventListener("click", function () {
                if (!confirm("Eliminar destino #" + b.dataset.delDest + "?")) return;
                fetch(API + "/admin/destinations/" + b.dataset.delDest, { method: "DELETE", headers: authHeaders() })
                    .then(function (r) { return r.json(); }).then(function () { showNotification("Destino eliminado", "success"); loadDestinations(); });
            });
        });
    });
}

function openDestModal(d) {
    var isEdit = !!d;
    document.getElementById("modalTitle").textContent = (isEdit ? "Editar" : "Adicionar") + " destino";
    var form = document.getElementById("modalForm");
    var v = d || {};
    var dest = v.destaques || [];
    form.innerHTML =
        field("Nome", "nome", v.nome, "text", true) +
        field("País", "pais", v.pais, "text", true) +
        field("Continente", "continente", v.continente, "text") +
        field("Tipo (separar por vírgula)", "tipo", v.tipo, "text") +
        field("Preço médio (EUR)", "preco_medio", v.preco_medio, "number") +
        field("Popularidade", "popularidade", v.popularidade, "number") +
        field("URL da imagem", "imagem_url", v.imagem_url, "text", false, true) +
        textarea("Descrição", "descricao", v.descricao) +
        field("Destaque 1", "destaque1", dest[0] || v.destaque1, "text") +
        field("Destaque 2", "destaque2", dest[1] || v.destaque2, "text") +
        field("Destaque 3", "destaque3", dest[2] || v.destaque3, "text") +
        field("Destaque 4", "destaque4", dest[3] || v.destaque4, "text") +
        modalActions();
    showModal();
    form.onsubmit = function (e) {
        e.preventDefault();
        var payload = collect(form);
        var url = isEdit ? API + "/admin/destinations/" + d.destination_id : API + "/admin/destinations";
        fetch(url, { method: isEdit ? "PUT" : "POST", headers: authHeaders(), body: JSON.stringify(payload) })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.status === "ok") { closeModal(); showNotification("Destino " + (isEdit ? "atualizado" : "criado"), "success"); loadDestinations(); }
                else showNotification(res.message || "Erro", "error");
            });
    };
}

// ============ PACKAGES ============
function loadPackages() {
    fetch(API + "/pacotes?lang=pt").then(function (r) { return r.json(); }).then(function (rows) {
        document.getElementById("pkgTbody").innerHTML = rows.map(function (p) {
            return '<tr><td>#' + p.package_id + '</td>' +
                '<td>' + esc(p.nome) + '</td>' +
                '<td>' + esc(p.destino_principal || "") + '</td>' +
                '<td>' + esc(p.categoria || "") + '</td>' +
                '<td>' + p.duracao + ' noites</td>' +
                '<td>' + fmtEur(p.preco) + '</td>' +
                '<td class="row-actions">' +
                    '<button class="icon-btn" data-edit-pkg="' + p.package_id + '" data-testid="edit-pkg-' + p.package_id + '"><i class="fas fa-pen"></i></button>' +
                    '<button class="icon-btn danger" data-del-pkg="' + p.package_id + '" data-testid="del-pkg-' + p.package_id + '"><i class="fas fa-trash"></i></button>' +
                '</td></tr>';
        }).join("");
        document.querySelectorAll("[data-edit-pkg]").forEach(function (b) {
            b.addEventListener("click", function () {
                var p = rows.find(function (x) { return x.package_id === parseInt(b.dataset.editPkg, 10); });
                openPkgModal(p);
            });
        });
        document.querySelectorAll("[data-del-pkg]").forEach(function (b) {
            b.addEventListener("click", function () {
                if (!confirm("Eliminar pacote #" + b.dataset.delPkg + "?")) return;
                fetch(API + "/admin/packages/" + b.dataset.delPkg, { method: "DELETE", headers: authHeaders() })
                    .then(function (r) { return r.json(); }).then(function () { showNotification("Pacote eliminado", "success"); loadPackages(); });
            });
        });
    });
}

function openPkgModal(p) {
    var isEdit = !!p;
    document.getElementById("modalTitle").textContent = (isEdit ? "Editar" : "Adicionar") + " pacote";
    var form = document.getElementById("modalForm");
    var v = p || {};
    var items = v.itens_incluidos || [];
    form.innerHTML =
        field("Nome", "nome", v.nome, "text", true) +
        field("Destino principal", "destino_principal", v.destino_principal, "text") +
        field("Categoria", "categoria", v.categoria, "text") +
        field("Duração (noites)", "duracao", v.duracao, "number") +
        field("Preço (EUR)", "preco", v.preco, "number") +
        field("Popularidade", "popularidade", v.popularidade, "number") +
        field("URL da imagem", "imagem_url", v.imagem_url, "text", false, true) +
        textarea("Descrição", "descricao", v.descricao) +
        field("Item 1", "item1", items[0] || v.item1, "text") +
        field("Item 2", "item2", items[1] || v.item2, "text") +
        field("Item 3", "item3", items[2] || v.item3, "text") +
        field("Item 4", "item4", items[3] || v.item4, "text") +
        modalActions();
    showModal();
    form.onsubmit = function (e) {
        e.preventDefault();
        var payload = collect(form);
        var url = isEdit ? API + "/admin/packages/" + p.package_id : API + "/admin/packages";
        fetch(url, { method: isEdit ? "PUT" : "POST", headers: authHeaders(), body: JSON.stringify(payload) })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.status === "ok") { closeModal(); showNotification("Pacote " + (isEdit ? "atualizado" : "criado"), "success"); loadPackages(); }
                else showNotification(res.message || "Erro", "error");
            });
    };
}

// ============ USERS ============
function loadUsers() {
    fetch(API + "/admin/users", { headers: authHeaders() })
        .then(function (r) { return r.json(); })
        .then(function (rows) {
            document.getElementById("usersTbody").innerHTML = rows.map(function (u) {
                return '<tr><td>#' + u.user_id + '</td>' +
                    '<td>' + esc(u.nome) + '</td>' +
                    '<td>' + esc(u.email) + '</td>' +
                    '<td>' + esc(u.telefone || "") + '</td>' +
                    '<td><span class="badge role-' + (u.role || "user") + '">' + (u.role || "user") + '</span></td>' +
                    '<td>' + fmtDate(u.data_criacao) + '</td></tr>';
            }).join("");
        });
}

// ============ Modal helpers ============
function field(label, name, value, type, required, span2) {
    return '<div' + (span2 ? ' class="span2"' : "") + '><label>' + label + '</label>' +
        '<input name="' + name + '" type="' + (type || "text") + '" value="' + esc(value) + '"' +
        (required ? " required" : "") + (type === "number" ? ' step="any"' : "") + '></div>';
}
function textarea(label, name, value) {
    return '<div class="span2"><label>' + label + '</label>' +
        '<textarea name="' + name + '">' + esc(value) + '</textarea></div>';
}
function modalActions() {
    return '<div class="modal-actions">' +
        '<button type="button" class="btn btn-outline-primary btn-sm" id="modalCancel">Cancelar</button>' +
        '<button type="submit" class="btn btn-primary btn-sm" data-testid="modal-save-btn"><i class="fas fa-save"></i> Guardar</button>' +
        '</div>';
}
function collect(form) {
    var data = {};
    new FormData(form).forEach(function (v, k) { data[k] = v === "" ? null : v; });
    return data;
}
function showModal() {
    document.getElementById("adminModal").style.display = "flex";
    setTimeout(function () {
        var c = document.getElementById("modalCancel");
        if (c) c.addEventListener("click", closeModal);
    }, 0);
}
function closeModal() { document.getElementById("adminModal").style.display = "none"; }
