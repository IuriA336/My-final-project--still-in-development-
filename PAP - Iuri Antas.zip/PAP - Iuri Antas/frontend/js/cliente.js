// ===================================
// Cliente Page JavaScript (Login/Register)
// ===================================

document.addEventListener("DOMContentLoaded", function() {
    // Redirect if already logged in
    var userId = localStorage.getItem("user_id");
    if (userId) {
        window.location.href = "dashboard.html";
        return;
    }

    setupAuthTabs();
    setupLogin();
    setupRegister();
});

function setupAuthTabs() {
    var tabs = document.querySelectorAll(".auth-tab");
    var forms = document.querySelectorAll(".auth-form");

    tabs.forEach(function(tab) {
        tab.addEventListener("click", function() {
            var target = tab.dataset.tab;

            tabs.forEach(function(t) { t.classList.remove("active"); });
            tab.classList.add("active");

            forms.forEach(function(form) {
                if (form.id === target + "Form") {
                    form.classList.add("active");
                } else {
                    form.classList.remove("active");
                }
            });
        });
    });
}

function setupLogin() {
    var form = document.getElementById("loginForm");
    if (!form) return;

    form.addEventListener("submit", function(e) {
        e.preventDefault();

        var email = document.getElementById("loginEmail").value.trim();
        var password = document.getElementById("loginPassword").value;

        if (!email || !password) {
            showNotification("Preencha todos os campos.", "error");
            return;
        }

        var btn = form.querySelector("button[type='submit']");
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Entrando...';

        fetch(API + "/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email: email, password: password })
        })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.status === "ok") {
                    localStorage.setItem("user_id", data.user_id);
                    localStorage.setItem("user_name", data.nome);
                    localStorage.setItem("user_role", data.role || "user");
                    localStorage.setItem("is_admin", data.is_admin ? "1" : "0");
                    showNotification("Login com sucesso! Redirecionando...", "success");
                    setTimeout(function() {
                        window.location.href = data.is_admin ? "admin.html" : "dashboard.html";
                    }, 1000);
                } else {
                    showNotification(data.message || "Credenciais invalidas.", "error");
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Entrar';
                }
            })
            .catch(function() {
                showNotification("Erro ao conectar ao servidor.", "error");
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Entrar';
            });
    });
}

function setupRegister() {
    var form = document.getElementById("registerForm");
    if (!form) return;

    form.addEventListener("submit", function(e) {
        e.preventDefault();

        var nome = document.getElementById("registerName").value.trim();
        var email = document.getElementById("registerEmail").value.trim();
        var telefone = document.getElementById("registerPhone").value.trim();
        var password = document.getElementById("registerPassword").value;

        if (!nome || !email || !password) {
            showNotification("Preencha todos os campos obrigatorios.", "error");
            return;
        }

        if (password.length < 6) {
            showNotification("A senha deve ter pelo menos 6 caracteres.", "error");
            return;
        }

        var btn = form.querySelector("button[type='submit']");
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Criando conta...';

        fetch(API + "/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nome: nome, email: email, telefone: telefone, password: password })
        })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.status === "ok") {
                    showNotification("Conta criada com sucesso! Faca login.", "success");
                    form.reset();
                    // Switch to login tab
                    document.querySelector('.auth-tab[data-tab="login"]').click();
                } else {
                    showNotification(data.message || "Erro ao criar conta.", "error");
                }
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-user-plus"></i> Criar Conta';
            })
            .catch(function() {
                showNotification("Erro ao conectar ao servidor.", "error");
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-user-plus"></i> Criar Conta';
            });
    });
}