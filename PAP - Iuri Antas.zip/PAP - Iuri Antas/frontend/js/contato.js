// ===================================
// Contact Page JavaScript
// ===================================

document.addEventListener("DOMContentLoaded", function() {
    setupContactForm();
    setupFAQ();
});

function setupContactForm() {
    var form = document.getElementById("contactForm");
    if (!form) return;

    form.addEventListener("submit", function(e) {
        e.preventDefault();

        var name = document.getElementById("contactName").value.trim();
        var email = document.getElementById("contactEmail").value.trim();
        var subject = document.getElementById("contactSubject").value.trim();
        var message = document.getElementById("contactMessage").value.trim();

        if (!name || !email || !subject || !message) {
            showNotification("Preencha todos os campos.", "error");
            return;
        }

        if (message.length < 10) {
            showNotification("A mensagem deve ter pelo menos 10 caracteres.", "error");
            return;
        }

        var btn = form.querySelector("button[type='submit']");
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';

        // Simulate sending
        setTimeout(function() {
            showNotification("Mensagem enviada com sucesso! Responderemos em ate 24 horas.", "success");
            form.reset();
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-paper-plane"></i> Enviar Mensagem';
        }, 1500);
    });
}

function setupFAQ() {
    var questions = document.querySelectorAll(".faq-question");

    questions.forEach(function(q) {
        q.addEventListener("click", function() {
            var item = q.parentElement;
            var answer = item.querySelector(".faq-answer");
            var isOpen = item.classList.contains("open");

            // Close all others
            document.querySelectorAll(".faq-item").forEach(function(fi) {
                fi.classList.remove("open");
                fi.querySelector(".faq-answer").style.maxHeight = null;
            });

            if (!isOpen) {
                item.classList.add("open");
                answer.style.maxHeight = answer.scrollHeight + "px";
            }
        });
    });
}