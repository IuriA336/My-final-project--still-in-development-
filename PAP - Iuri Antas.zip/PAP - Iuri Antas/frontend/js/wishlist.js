// ===================================
// Wishlist Page JavaScript
// ===================================

document.addEventListener("DOMContentLoaded", function () {
    loadWishlistPage();
});

function loadWishlistPage() {
    var userId = localStorage.getItem("user_id");
    var container = document.getElementById("wishlistPage");

    if (!userId) {
        container.innerHTML = '<div class="empty-state-full">' +
            '<i class="fas fa-user-lock"></i>' +
            '<h3>Faça login para ver a sua lista de desejos</h3>' +
            '<p>Os seus destinos de sonho são guardados na sua conta.</p>' +
            '<a href="cliente.html" class="btn btn-primary">Entrar / Criar Conta</a>' +
        '</div>';
        return;
    }

    apiFetch("/dreams/" + userId)
        .then(function (r) { return r.json(); })
        .then(function (dreams) {
            if (dreams.length === 0) {
                container.innerHTML = '<div class="empty-state-full">' +
                    '<i class="fas fa-heart-broken"></i>' +
                    '<h3>A sua lista de desejos está vazia</h3>' +
                    '<p>Explore os nossos destinos e adicione os seus favoritos clicando no coração.</p>' +
                    '<a href="destinos.html" class="btn btn-primary">Explorar Destinos</a>' +
                '</div>';
                return;
            }

            container.innerHTML = '<h2>' + dreams.length + ' destino(s) na sua lista</h2>' +
                '<div class="wishlist-page-grid">' +
                    dreams.map(function (d) {
                        var types = (d.tipo || "").split(",").filter(Boolean).map(function (tt) {
                            return '<span class="dest-tag">' + escapeHtml(localizeType(tt.trim())) + '</span>';
                        }).join("");

                        return '<div class="wishlist-page-card">' +
                            '<div class="wpc-img">' +
                                '<img src="' + encodeURI(d.imagem_url || "") + '" alt="' + escapeHtml(d.nome) + '">' +
                            '</div>' +
                            '<div class="wpc-body">' +
                                '<h3>' + escapeHtml(d.nome) + '</h3>' +
                                '<p class="wpc-country"><i class="fas fa-map-marker-alt"></i> ' + escapeHtml(d.pais) + '</p>' +
                                '<p class="wpc-desc">' + escapeHtml((d.descricao || "").substring(0, 120)) + '...</p>' +
                                '<div class="wpc-tags">' + types + '</div>' +
                                '<div class="wpc-footer">' +
                                    '<span class="wpc-price">' + fmt(d.preco_medio) + '</span>' +
                                    '<button class="btn btn-danger btn-sm" onclick="removeFromWishlistPage(' + d.dream_id + ')"><i class="fas fa-trash"></i> Remover</button>' +
                                '</div>' +
                            '</div>' +
                        '</div>';
                    }).join("") +
                '</div>';
        })
        .catch(function () {
            container.innerHTML = '<p>Erro ao carregar lista de desejos.</p>';
        });
}

function removeFromWishlistPage(dreamId) {
    fetch(API + "/dreams/delete/" + dreamId, { method: "DELETE" })
        .then(function (r) { return r.json(); })
        .then(function () {
            showNotification("Removido da lista de desejos.", "info");
            loadWishlistPage();
            updateWishlistCount();
        })
        .catch(function () {
            showNotification("Erro ao remover.", "error");
        });
}

window.removeFromWishlistPage = removeFromWishlistPage;
